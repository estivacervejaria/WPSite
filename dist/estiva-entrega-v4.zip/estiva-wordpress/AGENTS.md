# Estiva v3

Use skills/estiva-wordpress/SKILL.md. O pedido de 28/10/2026 substitui o escopo
anterior PUB/Club: nova versão institucional, cardápio Deck editável e integração
com Elementor Pro, que o usuário informou estar em uma instalação local de testes.
Não copie a licença, não inclua o plugin Pro nos ZIPs do tema e não alegue testar
Pro sem acesso ao plugin real. Nunca invente contatos, métricas ou preços.

A versão anterior está preservada em previous/v2 e em backup fora do checkout.
Não a apague. Este checkout já é isolado; não crie worktrees sem pedido explícito.
Credenciais de QA ficam fora do repositório. Rode fixtures só em QA descartável.
Registre evidências da execução atual; não reutilize resultados antigos como novos.

## Revisão v4 — páginas e migração

O usuário pediu páginas Início, Unidades (PUB Ana Costa e quiosque Canal 3), Sobre e Contato. As oito páginas ausentes são criadas no primeiro acesso administrativo, preservando páginas existentes. Formulário destinado a faleconosco@estivacervejaria.com.br, confirmado pelo usuário. Fotos reais das duas unidades e histórico detalhado continuam pendentes; o site público segue bloqueado por HTTP 403. Não alegue migrar esses conteúdos sem os materiais. Testes de e-mail usam interceptor local, nunca disparam mensagem externa sem autorização. Evidências atuais em docs/evidence-v4; docs/evidence é histórico v3. Versão v3 preservada em previous/v3 e branch entrega-estiva-v3.
