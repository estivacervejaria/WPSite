<?php
if (!defined('ABSPATH')) { exit; }
foreach (['setup','menu','seed','contact','render','elementor','pro'] as $file) { require_once get_template_directory().'/inc/'.$file.'.php'; }
