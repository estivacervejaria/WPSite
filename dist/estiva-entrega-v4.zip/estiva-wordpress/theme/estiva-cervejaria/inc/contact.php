<?php
if (!defined('ABSPATH')) { exit; }
function estiva_contact_recipient() {
 $email=get_theme_mod('estiva_contact_email','faleconosco@estivacervejaria.com.br');
 if (!$email) { $email=get_theme_mod('estiva_email',''); }
 return is_email($email)?$email:sanitize_email(get_option('admin_email'));
}
function estiva_contact_result($status) {
 wp_safe_redirect(add_query_arg('estiva_contact',$status,estiva_link('contato')).'#fale-com-a-estiva',303);exit;
}
function estiva_contact_process($input,$ip='') {
 $field=static function ($key) use ($input) { return isset($input[$key]) && is_string($input[$key])?trim(wp_unslash($input[$key])):''; };
 if (!wp_verify_nonce($field('estiva_contact_nonce'),'estiva_contact_send')) { return 'expired'; }
 if ($field('website')) { return 'invalid'; }
 $name=sanitize_text_field($field('contact_name'));$email=$field('contact_email');$kind=$field('contact_kind');$message=sanitize_textarea_field($field('contact_message'));
 $kinds=['sugestao'=>'Sugestão','reclamacao'=>'Reclamação','elogio'=>'Elogio','duvida'=>'Dúvida','outro'=>'Outro assunto'];
 if (strlen($name)<2 || strlen($name)>160 || !is_email($email) || strlen($email)>254 || preg_match('/[\r\n]/',$email) || !isset($kinds[$kind]) || strlen($message)<10 || strlen($message)>10000 || $field('contact_privacy')!=='1') { return 'invalid'; }
 $recipient=estiva_contact_recipient();if (!is_email($recipient)) { return 'unavailable'; }
 // Store only a salted identifier and a counter, never raw IPs or messages.
 $key='estiva_contact_'.hash_hmac('sha256',$ip,wp_salt('nonce'));
 $count=(int)get_transient($key);if ($count>=5) { return 'limited'; }
 set_transient($key,$count+1,10*MINUTE_IN_SECONDS);
 $subject='[Estiva] '.$kinds[$kind];
 $body="Tipo: ".$kinds[$kind]."\nNome: ".$name."\nE-mail: ".$email."\n\n".$message;
 // Keep the site's configured sender; the visitor is only Reply-To.
 return wp_mail($recipient,$subject,$body,['Content-Type: text/plain; charset=UTF-8','Reply-To: '.$email])?'sent':'failed';
}
function estiva_contact_submit() {
 if (($_SERVER['REQUEST_METHOD']??'')!=='POST') { estiva_contact_result('invalid'); }
 $status=estiva_contact_process($_POST,sanitize_text_field($_SERVER['REMOTE_ADDR']??''));
 estiva_contact_result($status);
}
add_action('admin_post_nopriv_estiva_contact','estiva_contact_submit');
add_action('admin_post_estiva_contact','estiva_contact_submit');
function estiva_contact_form() {
 $messages=['sent'=>'Mensagem encaminhada para envio. Obrigado por falar com a Estiva!','expired'=>'Sua sessão expirou. Atualize esta página e tente novamente.','invalid'=>'Confira os campos e a confirmação de privacidade e tente novamente.','unavailable'=>'O envio está indisponível. Entre em contato pelo Instagram.','failed'=>'Não foi possível encaminhar sua mensagem. Tente novamente ou fale conosco pelo Instagram.','limited'=>'Limite de tentativas atingido. Aguarde dez minutos e tente novamente.'];
 $status=isset($_GET['estiva_contact']) && is_string($_GET['estiva_contact'])?sanitize_key(wp_unslash($_GET['estiva_contact'])):'';
 $id=wp_unique_id('estiva-contact-');ob_start(); ?>
 <section class="contact-form-panel" id="fale-com-a-estiva"><span class="eyebrow">Sua opinião faz parte</span><h2>Sugestões, reclamações<br>e elogios são bem-vindos.</h2><p>Conte como foi sua experiência ou tire uma dúvida com a nossa equipe.</p>
 <?php if (isset($messages[$status])) { echo '<p class="form-feedback" role="status">'.esc_html($messages[$status]).'</p>'; } ?>
 <form class="estiva-contact-form" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
 <input type="hidden" name="action" value="estiva_contact"><?php wp_nonce_field('estiva_contact_send','estiva_contact_nonce'); ?>
 <div class="form-row"><div><label for="<?php echo esc_attr($id); ?>name">Seu nome *</label><input id="<?php echo esc_attr($id); ?>name" name="contact_name" autocomplete="name" minlength="2" maxlength="160" required></div><div><label for="<?php echo esc_attr($id); ?>email">Seu e-mail *</label><input id="<?php echo esc_attr($id); ?>email" name="contact_email" type="email" autocomplete="email" maxlength="254" required></div></div>
 <label for="<?php echo esc_attr($id); ?>kind">Assunto *</label><select id="<?php echo esc_attr($id); ?>kind" name="contact_kind" required><option value="">Selecione um assunto</option><option value="sugestao">Sugestão</option><option value="reclamacao">Reclamação</option><option value="elogio">Elogio</option><option value="duvida">Dúvida</option><option value="outro">Outro assunto</option></select>
 <label for="<?php echo esc_attr($id); ?>message">Sua mensagem *</label><textarea id="<?php echo esc_attr($id); ?>message" name="contact_message" rows="7" minlength="10" maxlength="10000" required aria-describedby="<?php echo esc_attr($id); ?>help"></textarea><p class="note" id="<?php echo esc_attr($id); ?>help">Campos com * são obrigatórios. Não inclua senhas, dados de cartão ou informações sensíveis.</p>
 <div class="contact-trap" aria-hidden="true"><label for="<?php echo esc_attr($id); ?>website">Deixe este campo vazio</label><input id="<?php echo esc_attr($id); ?>website" name="website" tabindex="-1" autocomplete="off"></div>
 <label class="privacy-check"><input type="checkbox" name="contact_privacy" value="1" required><span>Li a <a href="<?php echo esc_url(estiva_link('politica-de-privacidade')); ?>">Política de Privacidade</a> e estou ciente do uso dos meus dados para responder a esta mensagem. *</span></label>
 <button type="submit" class="button">Enviar mensagem<span class="arrow" aria-hidden="true"></span></button></form></section>
 <?php return ob_get_clean();
}
add_shortcode('estiva_contact_form','estiva_contact_form');
// Avoid caching visitor nonces and feedback on the canonical contact page.
add_action('template_redirect',function () { if (is_page('contato')) { if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE',true); }nocache_headers(); } });
