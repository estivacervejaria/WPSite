Estiva Cervejaria 4.0.0

Instalação: envie o ZIP do tema no painel WordPress e ative. Acesse o painel como administrador para criar as oito páginas ausentes automaticamente, preservando páginas existentes.
Aparência > Personalizar > Estiva: textos, Instagram, destinatário do formulário e fotos das unidades. Destinatário confirmado: faleconosco@estivacervejaria.com.br.
O formulário usa wp_mail; configure o serviço de correio do servidor e teste a entrega real antes de publicar.
PUB Avenida Ana Costa e quiosque Canal 3: fotos reais e história detalhada ainda dependem de material fornecido. Não são apresentados ano de fundação ou cronologia inventados.
Aparência > Importar conteúdo Estiva: 23 produtos Deck e seis cervejas de referência; preços a revisar.
Aparência > Preparar Elementor: prepara páginas originais. Modelos Elementor Pro são opcionais e exigem o plugin legítimo instalado. Não inclui plugin ou licença Pro.
O tema não armazena mensagens do formulário em seu banco. Revise a Política de Privacidade e as regras de cache. Consulte docs/INSTALL.md e docs/QA.md no pacote completo.
Fontes Barlow e Barlow Condensed sob SIL OFL; licenças em assets/fonts. Arte gráfica original em CSS; nenhuma foto externa de estabelecimento foi usada.
