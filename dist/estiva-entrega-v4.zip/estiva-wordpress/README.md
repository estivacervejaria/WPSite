# Estiva Cervejaria — v4

Tema WordPress instalável com páginas criadas automaticamente no primeiro acesso administrativo após ativação/atualização. Preserva o conteúdo existente e cria somente páginas ausentes.

- Início, Cervejas, Cardápio Deck, Unidades, Eventos, Sobre, Contato e Política de Privacidade.
- Unidades: PUB na Avenida Ana Costa e quiosque na praia do Canal 3; fotos reais substituíveis em Personalizar, ainda pendentes de fornecimento.
- Sobre: texto de apresentação editável; histórico detalhado depende de texto aprovado.
- Contato: Instagram e formulário para sugestões, reclamações, elogios, dúvidas e outros assuntos, com destino faleconosco@estivacervejaria.com.br.
- Elementor/Pro e fallback sem plugins; cardápio Deck editável mantém seu importador separado.

`theme/estiva-cervejaria` é o código do tema. `dist/estiva-cervejaria.zip` é o instalável. `docs/INSTALL.md` contém atualização e checklist de migração; `docs/QA.md` contém resultados e limitações; `scripts/` contém ferramentas de reprodução.

O plugin Pro/licença não é redistribuído. Credenciais e fixtures ativas de QA não integram o tema. O site público está inacessível por HTTP 403 neste ambiente; fotos e história completa não foram migradas. Versões anteriores estão preservadas em previous/, excluído dos pacotes.
