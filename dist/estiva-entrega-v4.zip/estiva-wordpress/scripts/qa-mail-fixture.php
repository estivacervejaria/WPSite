<?php
define('ESTIVA_QA_MAIL_CAPTURE',true);
// Disposable QA only. Never distributed with the theme.
add_filter('pre_wp_mail',static function ($value,$args) { file_put_contents('/tmp/estiva-qa-mail.json',json_encode(['recipient'=>$args['to'],'subject'=>$args['subject'],'headers'=>$args['headers']]));return true; },10,2);
