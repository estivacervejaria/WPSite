from pathlib import Path
import subprocess,time,urllib.request,os
def run(args,**kwargs):
 kwargs.pop('check',None)
 p=subprocess.run(args,capture_output=True,**{k:v for k,v in kwargs.items() if k not in ('stdout','stderr')})
 if p.returncode:raise RuntimeError('QA setup command failed (arguments hidden to protect credentials)')
 return p
CONTAINER=os.environ.get('ESTIVA_ZIP_CONTAINER','estiva-v3-zip');PORT=os.environ.get('ESTIVA_ZIP_PORT','8081');PREFIX=os.environ.get('ESTIVA_ZIP_PREFIX','zip_v3_')
V=dict(x.split('=',1) for x in Path('/workspace/estiva-v3-runtime/runtime.env').read_text().splitlines())
run(['docker','run','-d','--name',CONTAINER,'--network','estiva-v3_default','-p','127.0.0.1:'+PORT+':80','-e','WORDPRESS_DB_HOST=db','-e','WORDPRESS_DB_NAME=estiva','-e','WORDPRESS_DB_USER=estiva','-e','WORDPRESS_DB_PASSWORD='+V['DB_PASSWORD'],'-e','WORDPRESS_TABLE_PREFIX='+PREFIX,'-v','/workspace/estiva-v3-runtime/wp-cli.phar:/usr/local/bin/wp:ro','wordpress:php8.3-apache@sha256:81a34254acaa6ff3b9a67268c2745e9a041c4094cbe5ccd35b75ed3bbdc033b5'],check=True,stdout=subprocess.DEVNULL)
for i in range(30):
 try:urllib.request.urlopen('http://localhost:'+PORT+'/wp-login.php',timeout=2);break
 except Exception:time.sleep(.5)
a=['docker','exec',CONTAINER,'php','/usr/local/bin/wp','--allow-root']
run(a+['core','install','--url=http://localhost:'+PORT,'--title=Estiva ZIP QA','--admin_user=estiva_qa','--admin_password='+V['ADMIN_PASSWORD'],'--admin_email=qa@example.invalid','--skip-email'],check=True)
for args in [['config','set','WPLANG','pt_BR'],['rewrite','structure','/%postname%/'],['config','set','WP_DEBUG','true','--raw'],['config','set','WP_DEBUG_LOG','true','--raw'],['config','set','WP_DEBUG_DISPLAY','false','--raw']]:run(a+args,check=True)
run(['docker','exec',CONTAINER,'chown','-R','www-data:www-data','/var/www/html/wp-content'],check=True)
