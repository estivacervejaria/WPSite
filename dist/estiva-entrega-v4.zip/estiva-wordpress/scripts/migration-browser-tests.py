from pathlib import Path
import os,json,subprocess
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];BASE=os.environ.get('ESTIVA_TEST_URL','http://localhost:8080');OUT=R/'docs/evidence-v4';OUT.mkdir(exist_ok=True);checks=[]
def check(name,ok):
 checks.append({'test':name,'passed':bool(ok)})
 assert ok,name
# The anonymous POST must never reach an external mailbox.
CONTAINER='estiva-v3-wordpress-1';DEST='/var/www/html/wp-content/mu-plugins/estiva-qa-mail.php'
assert BASE=='http://localhost:8080','Mail fixture is restricted to the disposable primary QA instance'
assert subprocess.run(['docker','exec',CONTAINER,'test','-e',DEST]).returncode!=0,'Refusing to replace an existing mail fixture'
subprocess.run(['docker','exec',CONTAINER,'mkdir','-p','/var/www/html/wp-content/mu-plugins'],check=True)
subprocess.run(['docker','cp',str(R/'scripts/qa-mail-fixture.php'),CONTAINER+':'+DEST],check=True)
subprocess.run(['docker','exec',CONTAINER,'chmod','644',DEST],check=True)
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  for width in [360,768,1280,1440]:
   page.set_viewport_size({'width':width,'height':1000})
   for slug in ['','unidades','sobre','contato']:
    res=page.goto(BASE+'/'+slug+('/' if slug else ''));page.wait_for_load_state('networkidle');check(f'{slug or "home"} HTTP {width}',res.status==200);check(f'{slug} H1 {width}',page.locator('h1').count()==1);check(f'{slug} fits {width}',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    if slug=='unidades':check(f'2 units {width}',page.locator('.unit-with-photo').count()==2);check(f'locations {width}','Avenida Ana Costa' in page.locator('main').inner_text() and 'Canal 3' in page.locator('main').inner_text())
    if slug=='sobre':check(f'story content {width}',page.locator('.story-copy').count()==1)
    if slug=='contato':
     check(f'single form {width}',page.locator('.estiva-contact-form').count()==1);check(f'5 kinds {width}',page.locator('select[name=contact_kind] option').count()==6);check(f'Instagram {width}',page.locator('a[href="https://www.instagram.com/estivacervejaria/"]').count()>0)
    page.screenshot(path=str(OUT/f'{slug or "home"}-{width}.png'),full_page=True)
  page.goto(BASE+'/contato/');form=page.locator('.estiva-contact-form');form.locator('button[type=submit]').click();check('required validation',page.locator('input[name=contact_name]').evaluate('(el)=>!el.validity.valid'));check('form stays on page','/contato/' in page.url)
  page.locator('[name=contact_name]').fill('Teste local');page.locator('[name=contact_email]').fill('qa@example.invalid');page.locator('[name=contact_kind]').select_option('sugestao');page.locator('[name=contact_message]').fill('Sugestão de teste automatizado, sem envio externo.');page.locator('[name=contact_privacy]').check();form.locator('button[type=submit]').click();page.wait_for_load_state('networkidle');check('actual anonymous POST redirects','estiva_contact=sent' in page.url);check('success feedback visible','encaminhada para envio' in page.locator('.form-feedback').inner_text())
  res=page.request.post(BASE+'/wp-admin/admin-post.php',form={'action':'estiva_contact','estiva_contact_nonce':'invalid'},max_redirects=0);check('invalid nonce redirects safely',res.status==303 and 'expired' in res.headers.get('location',''))
  page.goto(BASE+'/contato/?estiva_contact=failed');check('failure feedback','Não foi possível' in page.locator('.form-feedback').inner_text());check('no JS errors',not errors);b.close()
finally:
 subprocess.run(['docker','exec',CONTAINER,'rm','-f',DEST,'/tmp/estiva-qa-mail.json'],check=True)
(OUT/'migration-browser-results.json').write_text(json.dumps(checks,indent=2));print(len(checks),'migration browser assertions passed')
