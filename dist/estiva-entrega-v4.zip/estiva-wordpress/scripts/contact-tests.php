<?php
function estiva_check($label,$ok) { if (!$ok) { throw new RuntimeException($label); }echo "PASS: $label\n"; }
$sent=[];$mail=function ($result,$args) use (&$sent) { $sent[]=$args;return true; };add_filter('pre_wp_mail',$mail,10,2);
$base=['estiva_contact_nonce'=>wp_create_nonce('estiva_contact_send'),'contact_name'=>'Visitante de teste','contact_email'=>'qa@example.invalid','contact_kind'=>'elogio','contact_message'=>'Uma mensagem de teste local.','contact_privacy'=>'1'];
$ip='test-v4-'.wp_generate_uuid4();$key='estiva_contact_'.hash_hmac('sha256',$ip,wp_salt('nonce'));
try {
 estiva_check('receiver confirmed by user',estiva_contact_recipient()==='faleconosco@estivacervejaria.com.br');
 foreach (['estiva_contact_nonce'=>'bad','contact_email'=>"qa@example.invalid\r\nBcc: other@example.invalid",'contact_kind'=>'spam','contact_message'=>'tiny','contact_name'=>['array'],'contact_privacy'=>'','website'=>'spam.example'] as $keyfield=>$value) { $v=$base;$v[$keyfield]=$value;estiva_check('reject '.$keyfield,estiva_contact_process($v,$ip)!=='sent'); }
 estiva_check('validation never sends mail',count($sent)===0);
 foreach (['sugestao','reclamacao','elogio','duvida','outro'] as $kind) { $v=$base;$v['contact_kind']=$kind;estiva_check('valid '.$kind,estiva_contact_process($v,$ip)==='sent'); }
 estiva_check('five messages captured locally',count($sent)===5);
 estiva_check('recipient server-controlled',$sent[0]['to']==='faleconosco@estivacervejaria.com.br');
 estiva_check('reply-to visitor',in_array('Reply-To: qa@example.invalid',$sent[0]['headers'],true));
 estiva_check('plain text',in_array('Content-Type: text/plain; charset=UTF-8',$sent[0]['headers'],true));
 estiva_check('rate limit',estiva_contact_process($base,$ip)==='limited' && count($sent)===5);
 delete_transient($key);remove_filter('pre_wp_mail',$mail,10);$failed=static function () { return false; };add_filter('pre_wp_mail',$failed);
 estiva_check('transport failure visible',estiva_contact_process($base,$ip)==='failed');remove_filter('pre_wp_mail',$failed);
 $id=get_page_by_path('sobre')->ID;$original=get_post($id)->post_content;
 estiva_check('repeat pages creates zero',estiva_create_pages()===0);
 estiva_check('existing body preserved',get_post($id)->post_content===$original);
 estiva_check('front page exists',get_post(get_option('page_on_front'))->post_name==='inicio');
 estiva_check('two confirmed venues',count(estiva_public_units())===2);
 estiva_check('unit images have separate controls',isset(estiva_public_units()['brewpub'],estiva_public_units()['beach-bar']));
} finally { delete_transient($key);remove_filter('pre_wp_mail',$mail,10); }
echo "No real mail sent; fixtures removed.\n";
