# QA — Estiva Cervejaria v4

Execução em 28/10/2026, em instalações Docker descartáveis. WordPress 7.1.3, PHP 8.3.35, MariaDB 11.4.13, Elementor 4.3.4 e Elementor Pro 4.3.0 fornecido pelo usuário. Não houve mudança no servidor público nem na instalação local do usuário.

## Verificações executadas nesta revisão

| Verificação | Resultado |
|---|---|
| Regressão Chromium com Elementor Pro | 107 verificações aprovadas |
| Regressão com Elementor gratuito, sem Pro | 98 verificações aprovadas |
| Regressão sem Elementor, ZIP instalado em instância limpa | 98 verificações aprovadas |
| Início, Unidades, Sobre e Contato, 360/768/1280/1440 px, formulário HTTP | 79 verificações aprovadas |
| Upload real do ZIP, ativação e criação automática de páginas | 13 verificações aprovadas |
| Runtime: catálogo, fontes de dados, APIs Pro e segurança de campos | 129 verificações aprovadas |
| Formulário e criação de páginas | 25 verificações aprovadas |
| Editor Elementor | Unidades, Sobre e Contato editados, publicados e restaurados pelo editor real |
| axe-core 4.11.0, oito rotas em 360 e 1440 px | 16 varreduras, zero violações detectadas |
| PHP e estrutura obrigatória | 19 arquivos PHP sintaticamente válidos |

As verificações incluem HTTP 200, H1 único, ausência de overflow, rede social, cinco assuntos, validação de campos, nonce inválido, honeypot, injeção de cabeçalhos, dados não escalares, Reply-To, destinatário, limitação por hash de IP, falha de transporte e redirecionamento 303 após envio anônimo.

O envio foi interceptado por `pre_wp_mail` somente no ambiente de QA; nenhum e-mail real foi disparado. O teste HTTP exerceu admin-post.php, formulário e feedback. As fixtures foram removidas. Isso comprova a integração com a rotina de correio, não a entrega na caixa faleconosco@estivacervejaria.com.br, que precisa ser testada no servidor de destino com correio configurado.

Na instalação limpa, o tema criou as oito páginas sem importação manual, preservou uma página preexistente, definiu Início quando não havia página inicial configurada e não duplicou páginas no segundo acesso ao painel. O formulário e as unidades renderizaram sem Elementor. A importação opcional posterior criou 29 conteúdos (23 produtos e seis estilos); a segunda importação criou zero.

## Evidências e reprodução

As evidências desta revisão estão em **evidence-v4/**: JSONs, logs e capturas. **evidence/** contém os testes históricos da v3 e não é contado como execução da v4. A validação `installed-zip-verification.json` compara o ZIP final com o fonte e com a instalação limpa.

- `bash scripts/dev-up.sh`: sobe o QA principal com o Pro legítimo fora do repositório.
- `scripts/browser-tests.py`: usa ESTIVA_PROFILE, ESTIVA_TEST_URL e ESTIVA_EVIDENCE_DIR.
- `python scripts/migration-browser-tests.py`: usa somente o QA principal; instala um interceptor temporário de correio e o remove no finally. Aborta se já houver uma fixture nesse caminho. Nunca use em produção.
- `contact-tests.php` e `runtime-tests.php`: executar por WP-CLI como administrador no QA; a fixture de correio dos testes de contato impede envio externo.
- `python scripts/migration-editor-tests.py`: altera e restaura temporariamente os três documentos Elementor.
- `python scripts/accessibility-v4-tests.py`: usa Playwright/Chromium e axe-core local.
- Instalação limpa: `ESTIVA_ZIP_CONTAINER=estiva-v4-zip ESTIVA_ZIP_PORT=8082 ESTIVA_ZIP_PREFIX=zip_v4_ python scripts/zip-install-env.py`, seguida de `python scripts/upload-v4-tests.py`. Exige contêiner/tabelas ainda inexistentes.
- `python scripts/package.py` e `python scripts/package-complete.py`: empacotamento.

## Limitações e pendências de conteúdo

O proxy de rede retornou HTTP 403 para o site atual, Instagram e referência Nicdark; não houve extração editorial ou de mídia do site publicado. O usuário confirmou as duas localizações e o destinatário do formulário. **As fotos reais do PUB e do quiosque não foram fornecidas**: são mostrados espaços de foto em preparação, com controles separados na biblioteca de mídia. **O histórico detalhado não foi fornecido**: Sobre contém apenas uma apresentação breve com fatos confirmados, editável no painel. Não há ano de fundação, nomes de fundadores ou marcos inventados.

Os preços Deck permanecem referências do PDF. Contatos complementares, número de endereço, horários e política de retenção precisam de revisão. O modelo de privacidade é inicial, não uma política jurídica final. Algumas verificações axe são inconclusivas e pedem revisão humana; não se trata de certificação.

Não foram testados envio real de e-mail, DNS, SMTP comercial, Safari, leitor de tela humano, migração de banco de produção, troca de servidor, licença Pro ou biblioteca em nuvem. O suporte de arquivo do Theme Builder não foi exercitado com um modelo archive próprio. Os logs históricos contêm avisos de rede dos serviços WordPress.org e erros de permissão durante a preparação local, corrigidos com normalização 755/644; não se alega que os avisos externos tenham desaparecido. Não foram desativadas verificações TLS ou assinaturas. Após a correção, os testes de páginas HTTP e do ZIP final passaram.

Não há plugin Pro, licença, banco de QA, credencial ou fixture ativa de envio no ZIP do tema.
