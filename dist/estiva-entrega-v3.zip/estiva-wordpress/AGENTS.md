# Estiva v3

Use skills/estiva-wordpress/SKILL.md. O pedido de 28/10/2026 substitui o escopo
anterior PUB/Club: nova versão institucional, cardápio Deck editável e integração
com Elementor Pro, que o usuário informou estar em uma instalação local de testes.
Não copie a licença, não inclua o plugin Pro nos ZIPs do tema e não alegue testar
Pro sem acesso ao plugin real. Nunca invente contatos, métricas ou preços.

A versão anterior está preservada em previous/v2 e em backup fora do checkout.
Não a apague. Este checkout já é isolado; não crie worktrees sem pedido explícito.
Credenciais de QA ficam fora do repositório. Rode fixtures só em QA descartável.
Registre evidências da execução atual; não reutilize resultados antigos como novos.
