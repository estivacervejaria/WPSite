<?php
if (!defined('ABSPATH')) { exit; }
function estiva_pro_available() { return defined('ELEMENTOR_PRO_VERSION') && class_exists('\ElementorPro\Modules\ThemeBuilder\Module'); }
add_action('elementor/dynamic_tags/register',function ($manager) {
 if (!class_exists('\Elementor\Core\DynamicTags\Tag')) { return; }
 require_once __DIR__.'/pro-tag.php';$manager->register_group('estiva',['title'=>'Estiva Cervejaria']);$manager->register(new Estiva_Menu_Data_Tag());
});
function estiva_query_deck($query) {
 $query->set('post_type','estiva_menu_item');$query->set('meta_key','_estiva_order');$query->set('orderby','meta_value_num');$query->set('order','ASC');
 $existing=$query->get('meta_query');$scoped=['key'=>'_estiva_unit','value'=>'deck','compare'=>'='];$query->set('meta_query',$existing?['relation'=>'AND',$existing,$scoped]:[$scoped]);
}
add_action('elementor/query/estiva_deck','estiva_query_deck');
add_action('elementor/query/estiva_cervejas',function ($query) { $query->set('post_type','estiva_beer');$query->set('orderby','title');$query->set('order','ASC'); });
function estiva_dynamic_price($key) {
 $tag=\Elementor\Plugin::$instance->dynamic_tags->tag_data_to_tag_text(substr(md5($key),0,7),'estiva-menu-field',['field'=>'price']);
 return estiva_widget('heading',['title'=>'','header_size'=>'p','__dynamic__'=>['title'=>$tag],'title_color'=>'#F3C316','typography_typography'=>'custom','typography_font_family'=>'Barlow','typography_font_size'=>['size'=>26,'unit'=>'px'],'_css_classes'=>'estiva-price-value'],$key);
}
function estiva_pro_models() {
 return [
  'header'=>['title'=>'Estiva — Cabeçalho','elements'=>[estiva_section([estiva_widget('shortcode',['shortcode'=>'[estiva_header]'],'pro:header')],'pro:header','estiva-shell')]],
  'footer'=>['title'=>'Estiva — Rodapé','elements'=>[estiva_section([estiva_widget('shortcode',['shortcode'=>'[estiva_footer]'],'pro:footer')],'pro:footer','estiva-shell')]],
  'single-post'=>['title'=>'Estiva — Item do cardápio','elements'=>[estiva_section([
   estiva_widget('theme-post-title',['header_size'=>'h1','title_color'=>'#f6f3eb','typography_typography'=>'custom','typography_font_family'=>'Barlow Condensed'],'pro:single-title'),
   estiva_dynamic_price('pro:single-price'),
   estiva_widget('shortcode',['shortcode'=>'[estiva_item_field field="portion"]'],'pro:single-portion'),
   estiva_widget('theme-post-content',[],'pro:single-content'),
   estiva_widget('shortcode',['shortcode'=>'[estiva_item_field field="available"]'],'pro:single-available'),
   estiva_widget('shortcode',['shortcode'=>'[estiva_item_notice]'],'pro:single-notice')
  ],'pro:single','container section estiva-pro-item')]],
  'loop-item'=>['title'=>'Estiva — Cartão de item Deck','elements'=>[estiva_section([
   estiva_widget('theme-post-title',['header_size'=>'h3','title_color'=>'#f6f3eb','typography_typography'=>'custom','typography_font_family'=>'Barlow Condensed'],'pro:loop-title'),
   estiva_dynamic_price('pro:loop-price'),
   estiva_widget('shortcode',['shortcode'=>'[estiva_item_field field="description"]'],'pro:loop-description'),
   estiva_widget('shortcode',['shortcode'=>'[estiva_item_field field="available"]'],'pro:loop-available')
  ],'pro:loop','estiva-loop-card')]]
 ];
}
function estiva_seed_pro($apply=false) {
 if (!estiva_pro_available()) { return new WP_Error('missing_pro','Ative o Elementor Pro oficial para criar os modelos.'); }
 if (!current_user_can('manage_options')) { return new WP_Error('permission','Esta ação exige permissão administrativa.'); }
 $count=0;$ids=[];
 foreach (estiva_pro_models() as $type=>$model) {
  $existing=get_posts(['post_type'=>'elementor_library','post_status'=>'any','meta_key'=>'_estiva_pro_key','meta_value'=>'v3:'.$type,'numberposts'=>1]);
  if ($existing) { $id=$existing[0]->ID; }
  else {
   $document=\Elementor\Plugin::$instance->documents->create($type,['post_title'=>$model['title'],'post_status'=>'draft'],['_estiva_pro_key'=>'v3:'.$type]);
   if (is_wp_error($document)) { return $document; }
   if (!$document) { return new WP_Error('document','Não foi possível criar o modelo '.$type); }
   $id=$document->get_main_id();$preview=estiva_items();$settings=($type==='single-post' && $preview)?['preview_type'=>'single/estiva_menu_item','preview_id'=>(string)$preview[0]->ID]:[];$document->save(['elements'=>$model['elements'],'settings'=>$settings]);$count++;
  }
  $ids[$type]=$id;
  if ($apply) {
   wp_update_post(['ID'=>$id,'post_status'=>'publish']);
   if ($type!=='loop-item') {
    $conditions=$type==='single-post'?[['type'=>'include','name'=>'singular','sub_name'=>'estiva_menu_item']]:[['type'=>'include','name'=>'general']];
    \ElementorPro\Modules\ThemeBuilder\Module::instance()->get_conditions_manager()->save_conditions($id,$conditions);
   }
  }
 }
 \Elementor\Plugin::$instance->files_manager->clear_cache();return ['created'=>$count,'ids'=>$ids,'applied'=>$apply];
}
add_action('admin_menu',function () { add_theme_page('Elementor Pro Estiva','Modelos Elementor Pro','manage_options','estiva-pro',function () {
 if (!current_user_can('manage_options')) { return; }
 echo '<div class="wrap"><h1>Elementor Pro — modelos Estiva</h1><p>'.esc_html(estiva_pro_available()?'Elementor Pro detectado: '.ELEMENTOR_PRO_VERSION:'Elementor Pro não está ativo. O tema continua funcionando com o layout nativo.').'</p><p>Cria cabeçalho, rodapé, item individual e cartão de loop em rascunho. Nenhuma condição de exibição ou licença é alterada automaticamente. Revise os modelos no Theme Builder antes de publicar.</p>';
 if (isset($_POST['estiva_pro'])) { check_admin_referer('estiva_pro');$r=estiva_seed_pro(false);echo '<p>'.esc_html(is_wp_error($r)?$r->get_error_message():$r['created'].' modelos criados; existentes preservados.').'</p>'; }
 echo '<form method="post">';wp_nonce_field('estiva_pro');echo '<button class="button button-primary" name="estiva_pro" value="1">Criar modelos em rascunho</button></form></div>';
 }); });
if (defined('WP_CLI') && WP_CLI) { WP_CLI::add_command('estiva pro',function ($args,$assoc) { $r=estiva_seed_pro(isset($assoc['apply']));if (is_wp_error($r)) { WP_CLI::error($r->get_error_message()); }WP_CLI::success(wp_json_encode($r)); }); }
