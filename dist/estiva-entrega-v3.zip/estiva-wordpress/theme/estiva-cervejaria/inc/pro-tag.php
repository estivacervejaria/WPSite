<?php
if (!defined('ABSPATH')) { exit; }
class Estiva_Menu_Data_Tag extends \Elementor\Core\DynamicTags\Tag {
 public function get_name() { return 'estiva-menu-field'; }
 public function get_title() { return 'Estiva — dado do cardápio'; }
 public function get_group() { return 'estiva'; }
 public function get_categories() { return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY]; }
 protected function register_controls() { $this->add_control('field',['label'=>'Campo','type'=>\Elementor\Controls_Manager::SELECT,'default'=>'price','options'=>['price'=>'Preço BRL','description'=>'Descrição','portion'=>'Peso / unidades','unit'=>'Unidade','available'=>'Disponibilidade']]); }
 public function render() { echo esc_html(estiva_field_value(estiva_context_item_id(),sanitize_key($this->get_settings('field')))); }
}
