<?php
if (!defined('ABSPATH')) { exit; }
function estiva_pages() { return ['inicio'=>['Início','[estiva_home]'],'cervejas'=>['Cervejas','[estiva_beers]'],'cardapio-deck'=>['Cardápio Deck','[estiva_menu]'],'unidades'=>['Unidades','[estiva_units]'],'eventos'=>['Eventos','[estiva_events]'],'sobre'=>['Sobre','[estiva_about]'],'contato'=>['Contato','[estiva_contact]'],'politica-de-privacidade'=>['Política de Privacidade','<p>Modelo a revisar pelo responsável antes da publicação. Informe controlador, dados tratados, finalidades, bases legais, retenção, compartilhamento e canal para exercício dos direitos. Serviços externos têm políticas próprias. Este modelo não constitui aconselhamento jurídico.</p>']]; }
function estiva_seed() {
 $n=0;foreach (estiva_pages() as $slug=>$data) { if (!get_page_by_path($slug)) { $id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$data[0],'post_content'=>$data[1]],true);if (is_wp_error($id)) { return $id; }$n++; } }
 if (!get_option('page_on_front')) { update_option('show_on_front','page');update_option('page_on_front',get_page_by_path('inicio')->ID); }
 foreach (json_decode(file_get_contents(__DIR__.'/menu-data.json'),true) as $i=>$item) {
  $key='deck:'.sanitize_title($item['title']);if (get_posts(['post_type'=>'estiva_menu_item','post_status'=>'any','meta_key'=>'_estiva_source_key','meta_value'=>$key,'numberposts'=>1])) { continue; }
  $id=wp_insert_post(['post_type'=>'estiva_menu_item','post_status'=>'publish','post_title'=>$item['title'],'post_content'=>$item['description']],true);if (is_wp_error($id)) { return $id; }
  foreach (['price','description','portion','unit'] as $field) { update_post_meta($id,'_estiva_'.$field,$item[$field]); }
  foreach (['source_key'=>$key,'order'=>$i,'available'=>'1','featured'=>'0'] as $f=>$v) { update_post_meta($id,'_estiva_'.$f,$v); }wp_set_object_terms($id,$item['category'],'estiva_menu_category');$n++;
 }
 foreach (['Pilsner','American IPA','Hop Lager','Premium Lager','Chopp Black','Wine Beer'] as $name) { if (!get_page_by_path(sanitize_title($name),OBJECT,'estiva_beer')) { $id=wp_insert_post(['post_type'=>'estiva_beer','post_status'=>'publish','post_name'=>sanitize_title($name),'post_title'=>$name,'post_content'=>'Estilo presente no material institucional. Consulte a unidade sobre características e disponibilidade atuais.'],true);if (is_wp_error($id)) { return $id; }$n++; } }
 flush_rewrite_rules();return $n;
}
add_action('admin_menu',function () { add_theme_page('Conteúdo Estiva','Importar conteúdo Estiva','manage_options','estiva-import',function () {
 if (!current_user_can('manage_options')) { return; }echo '<div class="wrap"><h1>Conteúdo inicial Estiva</h1><p>Adiciona oito páginas, seis cervejas e 23 itens exclusivamente no Deck. Preserva conteúdos existentes. Ativar o tema não importa dados automaticamente.</p>';
 if (isset($_POST['estiva_import'])) { check_admin_referer('estiva_import');$n=estiva_seed();echo '<p>'.esc_html(is_wp_error($n)?$n->get_error_message():$n.' conteúdos criados.').'</p>'; }echo '<form method="post">';wp_nonce_field('estiva_import');echo '<button class="button button-primary" name="estiva_import" value="1">Importar conteúdo</button></form></div>';
 }); });
if (defined('WP_CLI') && WP_CLI) { WP_CLI::add_command('estiva seed',function () { $n=estiva_seed();if (is_wp_error($n)) { WP_CLI::error($n->get_error_message()); }WP_CLI::success($n.' conteúdos criados.'); }); }
