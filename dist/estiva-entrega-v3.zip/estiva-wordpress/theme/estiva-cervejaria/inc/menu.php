<?php
if (!defined('ABSPATH')) { exit; }
add_action('init',function () {
 register_post_type('estiva_menu_item',['labels'=>['name'=>'Cardápio Estiva','singular_name'=>'Item do cardápio'],'public'=>true,'show_in_rest'=>true,'menu_icon'=>'dashicons-food','supports'=>['title','editor','thumbnail'],'rewrite'=>['slug'=>'item-deck']]);
 register_taxonomy('estiva_menu_category','estiva_menu_item',['label'=>'Categorias do cardápio','public'=>true,'hierarchical'=>true,'show_in_rest'=>true]);
 register_post_type('estiva_beer',['labels'=>['name'=>'Cervejas','singular_name'=>'Cerveja'],'public'=>true,'show_in_rest'=>true,'menu_icon'=>'dashicons-store','supports'=>['title','editor','thumbnail'],'rewrite'=>['slug'=>'cerveja']]);
});
function estiva_fields() { return ['unit'=>'Unidade obrigatória','price'=>'Preço BRL (vazio = consultar)','description'=>'Descrição curta','portion'=>'Peso / unidades','featured'=>'Destaque','available'=>'Disponível','order'=>'Ordem']; }
add_action('add_meta_boxes',function () { add_meta_box('estiva_fields','Informações do cardápio',function ($post) {
 wp_nonce_field('estiva_menu_save','estiva_menu_nonce');
 echo '<p>O impresso de referência é exclusivo do Deck. Não transfira seus preços automaticamente para outras unidades.</p>';
 foreach (estiva_fields() as $key=>$label) {
  $v=get_post_meta($post->ID,'_estiva_'.$key,true);$id='estiva_'.$key;echo '<p><label for="'.esc_attr($id).'">'.esc_html($label).'</label><br>';
  if ($key==='unit') { echo '<select required name="estiva_unit" id="estiva_unit"><option value="">Selecione a unidade</option>';foreach (estiva_units() as $slug=>$name) { echo '<option value="'.esc_attr($slug).'" '.selected($v,$slug,false).'>'.esc_html($name).'</option>'; }echo '</select>'; }
  elseif (in_array($key,['featured','available'],true)) { if ($key==='available' && !metadata_exists('post',$post->ID,'_estiva_available')) { $v='1'; }echo '<input type="checkbox" name="'.esc_attr($id).'" id="'.esc_attr($id).'" value="1" '.checked($v,'1',false).'>'; }
  else { echo '<input style="width:100%" name="'.esc_attr($id).'" id="'.esc_attr($id).'" type="'.(in_array($key,['price','order'],true)?'number':'text').'" '.($key==='price'?'min="0" max="999999.99" step="0.01"':'').' value="'.esc_attr($v).'">'; }echo '</p>';
 }
 },'estiva_menu_item'); });
add_action('save_post_estiva_menu_item',function ($id) {
 if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($id) || !current_user_can('edit_post',$id) || !isset($_POST['estiva_menu_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['estiva_menu_nonce'])),'estiva_menu_save')) { return; }
 foreach (estiva_fields() as $key=>$label) {
  $raw=isset($_POST['estiva_'.$key]) && is_scalar($_POST['estiva_'.$key])?wp_unslash($_POST['estiva_'.$key]):'';
  $v=match($key) { 'unit'=>array_key_exists($raw,estiva_units())?$raw:'','price'=>preg_match('/^\d{1,6}(?:[.,]\d{1,2})?$/',$raw)?number_format((float)str_replace(',','.',$raw),2,'.',''):'','order'=>absint($raw),'featured','available'=>$raw==='1'?'1':'0','description'=>sanitize_textarea_field($raw),default=>sanitize_text_field($raw) };
  update_post_meta($id,'_estiva_'.$key,$v);
 }
});
function estiva_items($unit='deck') { if (!array_key_exists($unit,estiva_units())) { return []; }return get_posts(['post_type'=>'estiva_menu_item','numberposts'=>-1,'meta_key'=>'_estiva_order','orderby'=>'meta_value_num','order'=>'ASC','meta_query'=>[['key'=>'_estiva_unit','value'=>$unit,'compare'=>'=']]]); }
function estiva_field_value($id,$field) {
 if (get_post_type($id)!=='estiva_menu_item') { return ''; }
 $value=get_post_meta($id,'_estiva_'.$field,true);
 return match($field) { 'price'=>$value!==''?'R$ '.number_format((float)$value,2,',','.'):'Consulte a unidade','unit'=>estiva_units()[$value]??'','available'=>$value==='0'?'Indisponível':'Disponível','description','portion'=>$value,default=>'' };
}
function estiva_context_item_id() { $id=get_the_ID();if (get_post_type($id)==='estiva_menu_item') { return $id; }$id=get_queried_object_id();return get_post_type($id)==='estiva_menu_item'?$id:0; }
add_shortcode('estiva_item_field',function ($atts) { $a=shortcode_atts(['field'=>'price'],$atts);return '<span class="estiva-field">'.esc_html(estiva_field_value(estiva_context_item_id(),sanitize_key($a['field']))).'</span>'; });
add_filter('manage_estiva_menu_item_posts_columns',function ($columns) { $columns['estiva_unit']='Unidade';return $columns; });
add_action('manage_estiva_menu_item_posts_custom_column',function ($column,$id) { if ($column==='estiva_unit') { echo esc_html(estiva_field_value($id,'unit') ?: 'Sem unidade'); } },10,2);

add_shortcode('estiva_item_notice',function () { $id=estiva_context_item_id();if (!$id) { return ''; }$deck=get_post_meta($id,'_estiva_unit',true)==='deck';return '<p class="note">'.esc_html($deck?'Preço de referência do impresso Deck, sujeito a revisão e alteração. Confirme disponibilidade e alergênicos com a unidade.':'Confirme preços, disponibilidade e alergênicos com a unidade.').'</p>'; });
