<?php
if (!defined('ABSPATH')) { exit; }
add_action('after_setup_theme',function () {
 load_theme_textdomain('estiva-cervejaria',get_template_directory().'/languages');
 foreach (['title-tag','post-thumbnails','custom-logo','responsive-embeds','align-wide','editor-styles','automatic-feed-links'] as $feature) { add_theme_support($feature); }
 add_theme_support('html5',['search-form','gallery','caption','style','script']);
 add_editor_style('assets/site.css');register_nav_menus(['primary'=>'Principal','footer'=>'Rodapé']);
});
add_action('wp_enqueue_scripts',function () {
 wp_enqueue_style('estiva-site',get_template_directory_uri().'/assets/site.css',[],'3.0.0');
 wp_enqueue_script('estiva-site',get_template_directory_uri().'/assets/site.js',[],'3.0.0',true);
 $gold=sanitize_hex_color(get_theme_mod('estiva_gold','#F3C316')) ?: '#F3C316';$dark=sanitize_hex_color(get_theme_mod('estiva_dark','#111111')) ?: '#111111';
 wp_add_inline_style('estiva-site',':root{--gold:'.$gold.';--dark:'.$dark.'}');
});
function estiva_units() { return ['brewpub'=>'Brewpub','fabrica'=>'Fábrica','deck'=>'Deck','beach-bar'=>'Beach Bar']; }
function estiva_link($slug) { $p=get_page_by_path($slug);return $p?get_permalink($p):home_url('/'.$slug.'/'); }
function estiva_builder() { if (!class_exists('\Elementor\Plugin')) { return false; } $d=\Elementor\Plugin::$instance->documents->get(get_the_ID());return $d && $d->is_built_with_elementor(); }
function estiva_location($where) { return function_exists('elementor_theme_do_location') && elementor_theme_do_location($where); }
add_action('elementor/theme/register_locations',function ($manager) { $manager->register_all_core_location(); });
function estiva_native_nav() { echo '<ul>';foreach (['cervejas'=>'Cervejas','cardapio-deck'=>'Cardápio Deck','unidades'=>'Unidades','eventos'=>'Eventos','sobre'=>'Sobre','contato'=>'Contato'] as $s=>$label) { echo '<li><a href="'.esc_url(estiva_link($s)).'" '.(is_page($s)?'aria-current="page"':'').'>'.esc_html($label).'</a></li>'; }echo '</ul>'; }
add_action('customize_register',function ($c) {
 $c->add_section('estiva_brand',['title'=>'Estiva — identidade e conteúdo','priority'=>30]);
 $fields=['gold'=>['#F3C316','Amarelo aproximado','color'],'dark'=>['#111111','Carvão aproximado','color'],'hero_title'=>['Aqui você decide.','Título principal','text'],'hero_intro'=>['Cerveja artesanal, liberdade para escolher e bons encontros em Santos.','Texto principal','textarea'],'about_title'=>['Liberdade no copo. Histórias na mesa.','Título institucional','text'],'about_text'=>['A Estiva convida você a explorar estilos, descobrir o seu preferido e viver cada encontro do seu jeito.','Texto institucional','textarea'],'events_title'=>['Seu evento merece um brinde.','Título eventos','text'],'events_text'=>['Chopeiras, Bikebeer e Kombeer aparecem no material institucional. Consulte a equipe para confirmar formatos, disponibilidade e condições atuais.','Texto eventos','textarea'],'instagram'=>['https://www.instagram.com/estivacervejaria/','Instagram','url'],'whatsapp'=>['','URL WhatsApp confirmada','url'],'email'=>['','E-mail','email']];
 foreach (estiva_units() as $unit=>$label) { foreach (['address'=>'Endereço','hours'=>'Horários','url'=>'Link da unidade','whatsapp'=>'WhatsApp'] as $k=>$v) { $fields[$unit.'_'.$k]=['',$label.' — '.$v,in_array($k,['url','whatsapp'],true)?'url':'text']; } }
 foreach ($fields as $key=>$f) {
  $sanitize=match($f[2]) { 'url'=>'esc_url_raw','color'=>'sanitize_hex_color','email'=>'sanitize_email','textarea'=>'sanitize_textarea_field',default=>'sanitize_text_field' };
  $c->add_setting('estiva_'.$key,['default'=>$f[0],'sanitize_callback'=>$sanitize]);$args=['label'=>$f[1],'section'=>'estiva_brand','type'=>$f[2]];
  if ($f[2]==='color') { $c->add_control(new WP_Customize_Color_Control($c,'estiva_'.$key,$args)); } else { $c->add_control('estiva_'.$key,$args); }
 }
 foreach (['hero'=>'Imagem principal','ambience'=>'Imagem de ambiente'] as $k=>$v) { $c->add_setting('estiva_'.$k.'_image',['sanitize_callback'=>'absint']);$c->add_control(new WP_Customize_Media_Control($c,'estiva_'.$k.'_image',['section'=>'estiva_brand','label'=>$v.' (arquivo próprio/licenciado)','mime_type'=>'image'])); }
});
