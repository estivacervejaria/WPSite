<?php
/* Template Name: Estiva — Largura total */
if (!defined('ABSPATH')) { exit; }
require get_template_directory().'/page.php';
