<?php if (!defined('ABSPATH')) { exit; }get_header();if (!estiva_location('single')) { while (have_posts()) { the_post();the_content(); } }get_footer();
