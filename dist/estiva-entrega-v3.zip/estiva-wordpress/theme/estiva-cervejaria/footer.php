<?php if (!defined('ABSPATH')) { exit; } ?></main><?php if (!estiva_location('footer')) { echo estiva_footer_markup(); } wp_footer(); ?></body></html>
