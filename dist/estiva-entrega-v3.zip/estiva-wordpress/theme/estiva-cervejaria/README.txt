Estiva Cervejaria 3.0.0 — tema original GPL-2.0-or-later.

Instale o ZIP em Aparência > Temas. Importe os dados em Aparência >
Importar conteúdo Estiva. A importação é opt-in e idempotente: 8 páginas,
6 cervejas e 23 itens exclusivamente do Deck, com preços sujeitos a revisão.

Aparência > Personalizar: logo, paleta, textos, banners e contatos por unidade.
Cardápio Estiva: produtos, preços, descrição, porção, disponibilidade e ordem.

Com Elementor ativo, use Preparar Elementor. Com Pro, use Modelos Elementor Pro
para criar 4 templates em rascunho. Revise/publice no Theme Builder e defina
condições: cabeçalho/rodapé no site inteiro; Single nos itens do cardápio.
Query IDs: estiva_deck e estiva_cervejas. Dynamic Tag: Estiva — dado do cardápio.
O tema também funciona sem Elementor. Não contém o plugin Pro ou sua licença.

Fontes locais Barlow (400) e Barlow Condensed (700), de Jeremy Tribby,
licenciadas SIL OFL; licenças em assets/fonts/*OFL.txt. Ilustrações CSS e
screenshot são originais. Não inclui fotos de unidades ou logotipo oficial.

Os CPTs estão no tema. Trocar o tema preserva os dados no banco, mas sua
interface depende da reativação ou migração para plugin. Não há exclusão de
dados ao desativar. Confirme valores e informações operacionais antes de publicar.
