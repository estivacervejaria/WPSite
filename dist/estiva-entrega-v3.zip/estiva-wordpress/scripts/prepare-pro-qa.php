<?php
if (!estiva_pro_available()) { throw new RuntimeException('Requires the actual Pro plugin'); }
$models=estiva_seed_pro(false);if (is_wp_error($models)) { throw new RuntimeException($models->get_error_message()); }
$foreign=wp_insert_post(['post_type'=>'estiva_menu_item','post_status'=>'publish','post_title'=>'QA OTHER UNIT DO NOT IMPORT']);foreach (['unit'=>'brewpub','price'=>'999.99','order'=>0,'available'=>'1'] as $k=>$v) { update_post_meta($foreign,'_estiva_'.$k,$v); }
$document=\Elementor\Plugin::$instance->documents->create('wp-page',['post_type'=>'page','post_title'=>'QA — Pro Loop Grid','post_name'=>'estiva-qa-loop','post_status'=>'publish'],['_estiva_qa'=>'v3-loop']);if (is_wp_error($document)) { wp_delete_post($foreign,true);throw new RuntimeException($document->get_error_message()); }
$id=$document->get_main_id();$data=[estiva_section([
 estiva_widget('heading',['title'=>'QA — Pro Loop Grid','header_size'=>'h1','title_color'=>'#f6f3eb'],'qa:loop-title'),
 estiva_widget('loop-grid',['template_id'=>$models['ids']['loop-item'],'posts_per_page'=>50,'columns'=>3,'columns_tablet'=>2,'columns_mobile'=>1,'post_query_post_type'=>'post','post_query_query_id'=>'estiva_deck','pagination_type'=>''],'qa:loop-grid')
],'qa:loop-grid','container section')];$document->save(['elements'=>$data,'settings'=>[]]);update_post_meta($id,'_wp_page_template','page-templates/full-width.php');
echo wp_json_encode(['page_id'=>$id,'fixture_id'=>$foreign,'url'=>get_permalink($id)]);
