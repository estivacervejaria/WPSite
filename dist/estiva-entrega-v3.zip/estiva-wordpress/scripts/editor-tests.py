from pathlib import Path
import subprocess,json,re
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];V=dict(x.split('=',1) for x in Path('/workspace/estiva-v3-runtime/runtime.env').read_text().splitlines());results=[]
def wp(args):return subprocess.check_output(['docker','exec','estiva-v3-wordpress-1','php','/usr/local/bin/wp','--allow-root','--user=estiva_qa']+args,text=True)
ids=json.loads(wp(['eval',"$ids=[];foreach (['inicio','cardapio-deck'] as $slug) {$ids[$slug]=get_page_by_path($slug)->ID;}foreach (['header','footer'] as $type) {$p=get_posts(['post_type'=>'elementor_library','meta_key'=>'_estiva_pro_key','meta_value'=>'v3:'.$type,'numberposts'=>1]);$ids['pro-'.$type]=$p[0]->ID;}echo wp_json_encode($ids);"]))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000});page.set_default_timeout(60000);page.on('dialog',lambda d:d.accept());page.goto('http://localhost:8080/wp-login.php');page.locator('#user_login').fill('estiva_qa');page.locator('#user_pass').fill(V['ADMIN_PASSWORD']);page.locator('#wp-submit').click();page.wait_for_url('**/wp-admin/**',wait_until='domcontentloaded')
 def open_field(ident):
  page.goto(f'http://localhost:8080/wp-admin/post.php?post={ident}&action=elementor');frame=page.frame_locator('#elementor-preview-iframe');widget=frame.locator(f'[data-elementor-id="{ident}"] .elementor-widget-shortcode').first;widget.wait_for();widget.locator('.elementor-editor-element-edit').dispatch_event('click');f=page.locator('textarea[data-setting="shortcode"]');f.wait_for();return f
 def save(ident,code):
  f=open_field(ident);f.fill(code);page.wait_for_timeout(700)
  apply=page.get_by_role('button',name=re.compile(r'^(Apply|Aplicar)$'))
  if apply.count() and apply.first.is_visible():apply.first.click()
  page.wait_for_timeout(1500);page.get_by_role('button',name=re.compile(r'^(Publish|Update|Publicar|Atualizar)\b')).first.click();page.wait_for_timeout(2500)
 for label,ident in ids.items():
  field=open_field(ident);original=field.input_value().replace('\n<!-- estiva-v3-qa-save -->','');assert 'estiva_' in original;save(ident,original+'\n<!-- estiva-v3-qa-save -->');assert 'estiva-v3-qa-save' in wp(['post','meta','get',str(ident),'_elementor_data']);print(label,'save persisted',flush=True);save(ident,original);assert 'estiva-v3-qa-save' not in wp(['post','meta','get',str(ident),'_elementor_data']);page.screenshot(path=str(R/f'docs/evidence/editor-{label}.png'));results.append({'document':label,'editor_opened':True,'temporary_change_persisted':True,'original_restored_via_editor':True});(R/'docs/evidence/editor-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(label,'restored',flush=True)
 b.close()
