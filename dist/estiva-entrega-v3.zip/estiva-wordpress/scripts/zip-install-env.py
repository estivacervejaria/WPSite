from pathlib import Path
import subprocess,time,urllib.request
V=dict(x.split('=',1) for x in Path('/workspace/estiva-v3-runtime/runtime.env').read_text().splitlines())
subprocess.run(['docker','run','-d','--name','estiva-v3-zip','--network','estiva-v3_default','-p','127.0.0.1:8081:80','-e','WORDPRESS_DB_HOST=db','-e','WORDPRESS_DB_NAME=estiva','-e','WORDPRESS_DB_USER=estiva','-e','WORDPRESS_DB_PASSWORD='+V['DB_PASSWORD'],'-e','WORDPRESS_TABLE_PREFIX=zip_v3_','-v','/workspace/estiva-v3-runtime/wp-cli.phar:/usr/local/bin/wp:ro','wordpress:php8.3-apache@sha256:81a34254acaa6ff3b9a67268c2745e9a041c4094cbe5ccd35b75ed3bbdc033b5'],check=True,stdout=subprocess.DEVNULL)
for i in range(30):
 try:urllib.request.urlopen('http://localhost:8081/wp-login.php',timeout=2);break
 except Exception:time.sleep(.5)
a=['docker','exec','estiva-v3-zip','php','/usr/local/bin/wp','--allow-root']
subprocess.run(a+['core','install','--url=http://localhost:8081','--title=Estiva ZIP QA','--admin_user=estiva_qa','--admin_password='+V['ADMIN_PASSWORD'],'--admin_email=qa@example.invalid','--skip-email'],check=True)
for args in [['config','set','WPLANG','pt_BR'],['rewrite','structure','/%postname%/'],['config','set','WP_DEBUG','true','--raw'],['config','set','WP_DEBUG_LOG','true','--raw'],['config','set','WP_DEBUG_DISPLAY','false','--raw']]:subprocess.run(a+args,check=True)
subprocess.run(['docker','exec','estiva-v3-zip','chown','-R','www-data:www-data','/var/www/html/wp-content'],check=True)
