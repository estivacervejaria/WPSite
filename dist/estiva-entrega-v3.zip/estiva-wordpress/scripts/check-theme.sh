#!/usr/bin/env bash
set -euo pipefail
THEME="${1:-}";
if [[ -z "$THEME" || ! -d "$THEME" ]]; then echo 'Uso: check-theme.sh /caminho/estiva-cervejaria'; exit 2; fi
for f in style.css functions.php index.php header.php footer.php; do
  [[ -s "$THEME/$f" ]] || { echo "ERRO: falta $f"; exit 1; }
done
grep -Eq '^Theme Name:' "$THEME/style.css" || { echo 'ERRO: style.css sem Theme Name'; exit 1; }
if command -v php >/dev/null 2>&1; then
  while IFS= read -r -d '' file; do php -l "$file" >/dev/null; done < <(find "$THEME" -type f -name '*.php' -print0)
  echo 'OK: PHP sintaticamente válido'
else echo 'AVISO: PHP não disponível; lint não executado'; fi
echo 'OK: arquivos obrigatórios presentes'
