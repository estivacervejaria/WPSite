from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];results=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page()
 for width in [360,1440]:
  page.set_viewport_size({'width':width,'height':1000})
  for route in ['/','/cardapio-deck/','/cervejas/','/unidades/','/eventos/','/contato/','/item-deck/dadinho-de-tapioca/']:
   page.goto('http://localhost:8080'+route);page.add_script_tag(path='/workspace/estiva-runtime/tools/node_modules/axe-core/axe.min.js');a=page.evaluate("async()=>await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa','wcag22aa']}})");results.append({'route':route,'width':width,'violations':a['violations'],'passes':len(a['passes']),'incomplete':len(a['incomplete'])});print(width,route,[(v['id'],[n['target'] for n in v['nodes']]) for v in a['violations']],flush=True)
 b.close()
(R/'docs/evidence/axe-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));assert not any(a['violations'] for a in results)
