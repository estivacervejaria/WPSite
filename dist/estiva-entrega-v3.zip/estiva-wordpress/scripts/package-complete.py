"""Package current sources and evidence; exclude private runtimes and prior versions."""
from pathlib import Path
import zipfile
R=Path(__file__).resolve().parents[1]
files=[]
for name in ('theme','docs','scripts','skills'):
 files.extend(p for p in (R/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
files.extend(R/n for n in ('README.md','AGENTS.md','.gitignore','dist/estiva-cervejaria.zip','dist/SHA256SUMS'))
out=R/'dist/estiva-entrega-v3.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):
  assert not p.is_symlink()
  relative=p.relative_to(R)
  assert p.name not in ('runtime.env','elementor-pro.zip','wp-config.php')
  z.write(p,Path('estiva-wordpress')/relative)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
print(out)
