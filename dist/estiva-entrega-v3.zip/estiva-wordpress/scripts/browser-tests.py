from pathlib import Path
import os,json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];PROFILE=os.environ.get('ESTIVA_PROFILE','pro');BASE=os.environ.get('ESTIVA_TEST_URL','http://localhost:8080');OUT=Path(os.environ.get('ESTIVA_EVIDENCE_DIR',str(R/'docs/evidence'/PROFILE)));OUT.mkdir(parents=True,exist_ok=True);results=[]
def check(label,value):
 results.append({'test':label,'passed':bool(value)})
 if not value:raise AssertionError(label)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 for width in [360,768,1280,1440]:
  page.set_viewport_size({'width':width,'height':1000})
  for name,url in [('home','/'),('deck','/cardapio-deck/')]:
   response=page.goto(BASE+url);page.wait_for_load_state('networkidle');check(f'{name} HTTP 200 at {width}',response.status==200);check(f'{name} one H1 at {width}',page.locator('h1').count()==1);check(f'{name} fits {width}',page.evaluate('document.documentElement.scrollWidth<=innerWidth'));check(f'{name} one header at {width}',page.locator('[data-estiva-header]').count()==1);check(f'{name} one footer at {width}',page.locator('[data-estiva-footer]').count()==1)
   if PROFILE=='pro':check(f'{name} real Pro header at {width}',page.locator('[data-elementor-type="header"]').count()==1);check(f'{name} real Pro footer at {width}',page.locator('[data-elementor-type="footer"]').count()==1)
   else:check(f'{name} native header at {width}',page.locator('[data-elementor-type="header"]').count()==0)
   if name=='deck':check(f'23 items at {width}',page.locator('.menu-item-card').count()==23)
   page.screenshot(path=str(OUT/f'{name}-{width}.png'),full_page=True)
 page.set_viewport_size({'width':360,'height':850});page.goto(BASE+'/');check('Portuguese document language',page.locator('html').get_attribute('lang').lower()=='pt-br');page.keyboard.press('Tab');check('keyboard skip first',page.evaluate('document.activeElement.classList.contains("skip-link")'));page.keyboard.press('Enter');check('skip targets main',page.evaluate('document.activeElement.id==="main"'));page.locator('.nav-toggle').focus();page.keyboard.press('Enter');check('mobile nav keyboard opens',page.locator('.nav-toggle').get_attribute('aria-expanded')=='true');page.keyboard.press('Tab');check('nav link gets focus',page.evaluate('!!document.activeElement.closest("#estiva-navigation")'));page.keyboard.press('Escape');check('Escape closes and restores focus',page.locator('.nav-toggle').get_attribute('aria-expanded')=='false' and page.evaluate('document.activeElement.classList.contains("nav-toggle")'))
 page.goto(BASE+'/cardapio-deck/');search=page.locator('.menu-tools input');search.fill('salmão');check('search salmon',page.locator('.menu-item-card:visible').count()==1);search.fill('água');check('accented search',page.locator('.menu-item-card:visible').count()==1);search.fill('zzzz-noitem');check('zero results announced','Nenhum item' in page.locator('[role=status]').inner_text());search.fill('');page.get_by_role('button',name='Snacks',exact=True).click();check('category filter',page.locator('.menu-item-card:visible').count()==3);page.get_by_role('button',name='Tudo',exact=True).click();check('filter reset',page.locator('.menu-item-card:visible').count()==23);check('growler no invented price','Consulte a unidade' in page.locator('.menu-item-card',has=page.get_by_role('heading',name='Growler 1L',exact=True)).inner_text())
 for slug in ['cervejas','unidades','eventos','sobre','contato','politica-de-privacidade']:
  response=page.goto(BASE+'/'+slug+'/');check(slug+' renders',response.status==200 and bool(page.locator('main').inner_text().strip()));check(slug+' one H1',page.locator('h1').count()==1)
 page.goto(BASE+'/');hrefs=page.locator('a').evaluate_all('(els)=>els.map(e=>e.href)');check('no placeholder links',all(h and not h.endswith('/#') for h in hrefs))
 for href in sorted(set(h.split('#')[0] for h in hrefs if h.startswith(BASE))):check('internal link '+href,page.request.get(href).status==200)
 response=page.goto(BASE+'/item-deck/dadinho-de-tapioca/');check('item page HTTP 200',response.status==200);check('item title correct',page.locator('h1').all_text_contents()==['Dadinho de tapioca']);check('item price correct','R$ 47,00' in page.locator('main').inner_text());check('item reference notice','referência do impresso Deck' in page.locator('main').inner_text())
 if PROFILE=='pro':check('real Pro Single template',page.locator('[data-elementor-type="single-post"]').count()==1)
 check('local font served',page.request.get(BASE+'/wp-content/themes/estiva-cervejaria/assets/fonts/barlow-Barlow-Regular.ttf').status==200)
 response=page.goto(BASE+'/missing-estiva-page/');check('404 fallback',response.status==404 and 'Esse caminho' in page.locator('h1').inner_text());check('no JavaScript errors',not errors);b.close()
(OUT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(PROFILE,len(results),'browser assertions passed')
