#!/usr/bin/env bash
set -euo pipefail
# The existing checkout is isolated. Do not create a worktree.
repo="$(cd "$(dirname "$0")/.." && pwd)"
runtime=/workspace/estiva-v3-runtime
mkdir -p "$runtime"
if [[ ! -f "$runtime/runtime.env" ]]; then
 python - "$runtime/runtime.env" <<'PY'
from pathlib import Path
import secrets,sys
p=Path(sys.argv[1]);p.write_text('DB_PASSWORD='+secrets.token_urlsafe(24)+'\nADMIN_PASSWORD='+secrets.token_urlsafe(24)+'\n');p.chmod(0o600)
PY
fi
if [[ ! -s "$runtime/wp-cli.phar" ]]; then
 curl -fL --retry 2 https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar -o "$runtime/wp-cli.phar"
fi
docker compose -p estiva-v3 --env-file "$runtime/runtime.env" -f "$repo/scripts/compose.yaml" up -d
db_ready=0
for attempt in $(seq 1 30); do
 if docker exec estiva-v3-wordpress-1 php -r '$db=new mysqli("db",getenv("WORDPRESS_DB_USER"),getenv("WORDPRESS_DB_PASSWORD"),getenv("WORDPRESS_DB_NAME"));exit($db->connect_errno?1:0);' >/dev/null 2>&1; then db_ready=1; break; fi
 sleep 1
done
if [[ "$db_ready" != 1 ]]; then echo 'Banco de QA indisponível.' >&2; exit 1; fi
python - <<'PY'
import subprocess
from pathlib import Path
v=dict(x.split('=',1) for x in Path('/workspace/estiva-v3-runtime/runtime.env').read_text().splitlines());a=['docker','exec','estiva-v3-wordpress-1','php','/usr/local/bin/wp','--allow-root']
if subprocess.run(a+['core','is-installed'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
 subprocess.run(a+['core','install','--url=http://localhost:8080','--title=Estiva Cervejaria','--admin_user=estiva_qa','--admin_password='+v['ADMIN_PASSWORD'],'--admin_email=qa@example.invalid','--skip-email'],check=True)
for args in [['config','set','WP_DEBUG','true','--raw'],['config','set','WP_DEBUG_LOG','true','--raw'],['config','set','WP_DEBUG_DISPLAY','false','--raw'],['config','set','WPLANG','pt_BR'],['theme','activate','estiva-cervejaria'],['rewrite','structure','/%postname%/'],['estiva','seed']]:subprocess.run(a+args,check=True)
PY
if [[ ! -s "$runtime/elementor-free.zip" ]]; then
 curl -fL --retry 2 https://github.com/elementor/elementor/releases/download/4.3.4/elementor-4.3.4.zip -o "$runtime/elementor-free.zip"
fi
wpqa() { docker exec estiva-v3-wordpress-1 php /usr/local/bin/wp --allow-root --user=estiva_qa "$@"; }
if ! wpqa plugin is-installed elementor; then
 docker cp "$runtime/elementor-free.zip" estiva-v3-wordpress-1:/tmp/elementor.zip
 wpqa plugin install /tmp/elementor.zip
fi
wpqa plugin activate elementor
if ! wpqa plugin is-installed elementor-pro; then
 pro_zip="${ESTIVA_PRO_ZIP:-$runtime/elementor-pro.zip}"
 if [[ ! -s "$pro_zip" ]]; then echo 'Disponibilize o ZIP oficial do Elementor Pro fora do repositório para testar o Pro.' >&2; exit 1; fi
 docker cp "$pro_zip" estiva-v3-wordpress-1:/tmp/elementor-pro.zip
 wpqa plugin install /tmp/elementor-pro.zip
fi
wpqa plugin activate elementor-pro
wpqa estiva elementor
# Explicitly apply the supplied Pro models only in this disposable QA environment.
wpqa estiva pro --apply
wpqa eval 'if (!estiva_pro_available()) {WP_CLI::error("Pro module unavailable");}echo "Elementor Pro ".ELEMENTOR_PRO_VERSION." active\n";'
docker exec estiva-v3-wordpress-1 sh -c 'for d in wp-content/uploads wp-content/plugins wp-content/upgrade; do if [ -d "$d" ]; then chown -R www-data:www-data "$d"; fi; done'
curl -fsS http://localhost:8080/ -o "$runtime/ready-home.html"
curl -fsS http://localhost:8080/cardapio-deck/ -o "$runtime/ready-deck.html"
rg -q 'data-elementor-type="header"' "$runtime/ready-home.html"
rg -q 'data-unit="deck"' "$runtime/ready-deck.html"
rg -q 'Dadinho de tapioca' "$runtime/ready-deck.html"
echo 'WordPress + Elementor Pro + cardápio Deck: conteúdo funcional verificado.'
