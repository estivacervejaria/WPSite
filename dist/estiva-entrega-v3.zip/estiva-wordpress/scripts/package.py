from pathlib import Path
import zipfile,hashlib
R=Path(__file__).resolve().parents[1];T=R/'theme/estiva-cervejaria';D=R/'dist';D.mkdir(exist_ok=True)
for p in T.rglob('*'):p.chmod(0o755 if p.is_dir() else 0o644)
with zipfile.ZipFile(D/'estiva-cervejaria.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(T.rglob('*')):
  if p.is_file():
   if p.is_symlink():raise RuntimeError('Unexpected symlink in theme')
   z.write(p,p.relative_to(T.parent))
with zipfile.ZipFile(D/'estiva-cervejaria.zip') as z:assert z.testzip() is None;assert all(n.startswith('estiva-cervejaria/') for n in z.namelist());assert 'estiva-cervejaria/screenshot.png' in z.namelist()
p=D/'estiva-cervejaria.zip';(D/'SHA256SUMS').write_text(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n');print(p)
