from pathlib import Path
import subprocess,json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];E=R/'docs/evidence';results=[]
def wp(args):return subprocess.check_output(['docker','exec','estiva-v3-wordpress-1','php','/usr/local/bin/wp','--allow-root','--user=estiva_qa']+args,text=True)
subprocess.run(['docker','cp',str(R/'scripts/prepare-pro-qa.php'),'estiva-v3-wordpress-1:/tmp/prepare-pro-qa.php'],check=True)
info=json.loads(wp(['eval-file','/tmp/prepare-pro-qa.php']))
def check(name,value):
 results.append({'test':name,'passed':bool(value)})
 if not value:raise AssertionError(name)
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page()
  for width in [360,1440]:
   page.set_viewport_size({'width':width,'height':1000});res=page.goto(info['url']);page.wait_for_load_state('networkidle');text=page.locator('main').inner_text();print(text[:700])
   check(f'Loop HTTP 200 at {width}',res.status==200);check(f'Real Pro Loop widget at {width}',page.locator('.elementor-widget-loop-grid').count()==1);check(f'23 Deck loop items at {width}',page.locator('.elementor-widget-loop-grid .e-loop-item').count()==23);check(f'foreign unit excluded at {width}','QA OTHER UNIT' not in text and '999,99' not in text);check(f'first product dynamic title at {width}','Dadinho de tapioca' in text);check(f'first dynamic price at {width}','R$ 47,00' in text);check(f'other dynamic price at {width}','R$ 149,00' in text);check(f'no placeholder headings at {width}','Add Your Heading' not in text);check(f'Loop fits {width}',page.evaluate('document.documentElement.scrollWidth<=innerWidth'));page.screenshot(path=str(E/f'pro-loop-{width}.png'),full_page=True)
  b.close()
finally:
 wp(['post','delete',str(info['page_id']),str(info['fixture_id']),'--force'])
(E/'pro-loop-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(len(results),'Pro loop assertions passed; fixtures removed')
