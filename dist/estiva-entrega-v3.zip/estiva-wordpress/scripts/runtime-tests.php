<?php
// Execute only against the disposable, unmodified v3 QA fixtures.
function estiva_assert($ok,$label) { if (!$ok) { throw new RuntimeException($label); }echo 'PASS: '.$label."\n"; }
estiva_assert(count(estiva_items())===23,'23 Deck items');
estiva_assert(estiva_seed()===0,'native import idempotent');
estiva_assert(count(get_posts(['post_type'=>'estiva_beer','numberposts'=>-1]))===6,'six beer styles');
foreach (json_decode(file_get_contents(get_template_directory().'/inc/menu-data.json'),true) as $source) {
 $p=get_posts(['post_type'=>'estiva_menu_item','title'=>$source['title'],'numberposts'=>1]);$p=$p[0]??null;
 foreach (['price','description','portion','unit'] as $field) { estiva_assert($p && get_post_meta($p->ID,'_estiva_'.$field,true)===$source[$field],'source '.$field.': '.$source['title']); }
}
estiva_assert(estiva_pro_available(),'real Elementor Pro module active');
$r=estiva_seed_pro(false);estiva_assert(!is_wp_error($r) && $r['created']===0,'Pro import idempotent');
foreach ($r['ids'] as $type=>$id) { estiva_assert(get_post_type($id)==='elementor_library','real Pro document '.$type);estiva_assert(\Elementor\Plugin::$instance->documents->get($id)->get_name()===$type,'registered document type '.$type); }
foreach (['header','footer'] as $type) { estiva_assert(get_post_meta($r['ids'][$type],'_elementor_conditions',true)===['include/general'],'Pro global condition '.$type); }
estiva_assert(get_post_meta($r['ids']['single-post'],'_elementor_conditions',true)===['include/singular/estiva_menu_item'],'single condition scoped to menu items');
$tags=\Elementor\Plugin::$instance->dynamic_tags;estiva_assert((bool)$tags->get_tag_info('estiva-menu-field'),'custom dynamic tag registered');
$ids=[];
try {
 foreach (['deck'=>'11.11','brewpub'=>'22.22'] as $unit=>$price) { $id=wp_insert_post(['post_type'=>'estiva_menu_item','post_status'=>'publish','post_title'=>'QA fixture '.$unit]);$ids[$unit]=$id;foreach (['unit'=>$unit,'price'=>$price,'order'=>0,'description'=>'Fixture description','portion'=>'300 g','available'=>'1'] as $k=>$v) { update_post_meta($id,'_estiva_'.$k,$v); } }
 $q=new WP_Query();$q->set('posts_per_page',-1);do_action('elementor/query/estiva_deck',$q);$posts=$q->get_posts();estiva_assert(count($posts)===24,'Pro Query ID returns Deck only');estiva_assert(!in_array($ids['brewpub'],wp_list_pluck($posts,'ID'),true),'Pro query excludes Brewpub fixture');
 $GLOBALS['post']=get_post($ids['deck']);setup_postdata($GLOBALS['post']);
 estiva_assert(str_contains($tags->get_tag_data_content('qatest','estiva-menu-field',['field'=>'price']),'R$ 11,11'),'real dynamic price rendering');
 estiva_assert(str_contains($tags->get_tag_data_content('qatest','estiva-menu-field',['field'=>'portion']),'300 g'),'real dynamic portion rendering');
 estiva_assert(str_contains(do_shortcode('[estiva_item_field field="unit"]'),'Deck'),'contextual unit shortcode');
 estiva_assert(str_contains(do_shortcode('[estiva_item_notice]'),'referência'),'individual reference notice');
 estiva_assert(!str_contains(do_shortcode('[estiva_menu]'),'QA fixture brewpub'),'native Deck excludes other units');
 estiva_assert(str_contains(do_shortcode('[estiva_menu unit="invalid"]'),'inválida'),'invalid unit rejected');
 $id=$ids['deck'];wp_set_current_user(0);$_POST=['estiva_price'=>'999'];do_action('save_post_estiva_menu_item',$id);estiva_assert(get_post_meta($id,'_estiva_price',true)==='11.11','anonymous save denied');
 estiva_assert(is_wp_error(estiva_seed_pro()),'Pro setup denied without capability');
 $admins=get_users(['role'=>'administrator','number'=>1]);wp_set_current_user($admins[0]->ID);$_POST['estiva_menu_nonce']='invalid';do_action('save_post_estiva_menu_item',$id);estiva_assert(get_post_meta($id,'_estiva_price',true)==='11.11','invalid nonce denied');
 $_POST=['estiva_menu_nonce'=>wp_create_nonce('estiva_menu_save'),'estiva_unit'=>'deck','estiva_price'=>'47,50','estiva_description'=>'<script>alert(1)</script>Petisco','estiva_portion'=>'300 g','estiva_available'=>'1','estiva_featured'=>'1','estiva_order'=>'4'];do_action('save_post_estiva_menu_item',$id);
 estiva_assert(get_post_meta($id,'_estiva_price',true)==='47.50','decimal price normalized');estiva_assert(get_post_meta($id,'_estiva_description',true)==='Petisco','description sanitized');estiva_assert(get_post_meta($ids['brewpub'],'_estiva_price',true)==='22.22','editing Deck preserves other unit price');
 $_POST['estiva_price']='-1';do_action('save_post_estiva_menu_item',$id);estiva_assert(get_post_meta($id,'_estiva_price',true)==='','negative price rejected');
 $_POST['estiva_price']='1e5';do_action('save_post_estiva_menu_item',$id);estiva_assert(get_post_meta($id,'_estiva_price',true)==='','exponent price rejected');
 $_POST['estiva_unit']='invalid';do_action('save_post_estiva_menu_item',$id);estiva_assert(get_post_meta($id,'_estiva_unit',true)==='','invalid unit cleared');
 update_post_meta($id,'_estiva_unit','deck');update_post_meta($id,'_estiva_description','<img src=x onerror=alert(1)>');update_post_meta($id,'_estiva_available','0');ob_start();estiva_render_item(get_post($id));$html=ob_get_clean();estiva_assert(!str_contains($html,'<img src=x') && str_contains($html,'&lt;img'),'output escaped');estiva_assert(str_contains($html,'Indisponível'),'unavailable badge');estiva_assert(str_contains($html,'Destaque'),'featured badge');
} finally { $_POST=[];foreach ($ids as $id) { wp_delete_post($id,true); }wp_reset_postdata(); }
echo "All runtime checks completed; temporary fixtures removed.\n";
