# Instalação e uso

## 1. Instalar o tema

Esta versão foi feita para uma instalação nova de testes, conforme o pedido. Requisitos do tema: WordPress 6.8+ e PHP 8.1+. Testado com WordPress 7.1.3 e PHP 8.3.35.

1. Mantenha **Elementor** e **Elementor Pro** ativos na sua instalação. O teste usou Core 4.3.4 / Pro 4.3.0. O ZIP do tema não substitui nem inclui o plugin Pro ou a licença que você já possui.
2. Em **Aparência → Temas → Adicionar tema → Enviar tema**, envie `estiva-cervejaria.zip`, instale e ative.
3. Em **Aparência → Importar conteúdo Estiva**, clique **Importar conteúdo**. Isso cria oito páginas, seis cervejas e 23 itens exclusivamente no Deck. A ativação não importa nada silenciosamente. Repetir a importação cria zero registros quando os conteúdos já existem.
4. Em **Configurações → Leitura**, confirme Início como página inicial. O importador só faz isso se nenhuma home estiver configurada. Em **Links permanentes**, salve “Nome do post”. Configure o idioma do site como **Português do Brasil** em Geral.
5. Em **Aparência → Personalizar**, configure logo, paleta, textos principais, imagens, Instagram, e-mail, WhatsApp e endereço/horário/link de cada unidade. Os campos desconhecidos ficam vazios. Use imagens próprias/licenciadas e preencha o texto alternativo.
6. Se quiser menus personalizados, atribua-os às posições Principal e Rodapé. Sem menu principal atribuído, a navegação institucional funciona por fallback.

Páginas iniciais: Início, Cervejas, Cardápio Deck, Unidades, Eventos, Sobre, Contato e Política de Privacidade. A política é um modelo pendente de revisão, não aconselhamento jurídico.

## 2. Preparar as páginas Elementor

Em **Aparência → Preparar Elementor**, prepare as sete páginas originais. A política permanece nativa. A ação preserva páginas cujo conteúdo já foi personalizado e dados Elementor existentes.

Use **Editar com Elementor** para mover/remover os blocos e acrescentar widgets. Os blocos dinâmicos consultam os dados atuais do WordPress, em vez de manter uma cópia estática dos preços no layout. O hero já contém o H1: evite duplicá-lo ao adicionar títulos.

Shortcodes: `[estiva_hero]`, `[estiva_home]`, `[estiva_about]`, `[estiva_beers]`, `[estiva_deck_intro]`, `[estiva_menu]`, `[estiva_units]`, `[estiva_events]`, `[estiva_contact]`. O padrão de `[estiva_menu]` é exclusivamente Deck. No widget Shortcode, use Aplicar/Apply quando o controle aparecer e Atualizar/Publicar para salvar.

Textos gerais e identidade vêm do Customizer. Para criar conteúdo totalmente personalizado, substitua um bloco dinâmico por widgets Heading/Text Editor/Imagem. Cervejas são editadas no CPT Cervejas. Produtos e preços são editados no painel do cardápio.

Modelos nativos disponíveis: Largura total e Canvas. O canvas oficial do Elementor continua disponível e não é sobrescrito. Ao desativar os plugins, os shortcodes salvos continuam funcionando; o tema restaura os cabeçalhos/rodapés nativos e evita H1 duplicado.

## 3. Integração Elementor Pro / Theme Builder

Abra **Aparência → Modelos Elementor Pro** e clique **Criar modelos em rascunho**. São criados quatro modelos, sem alterar a licença ou publicar condições automaticamente:

| Modelo | Tipo | Uso |
|---|---|---|
| Estiva — Cabeçalho | Header | Cabeçalho compartilhado |
| Estiva — Rodapé | Footer | Rodapé compartilhado |
| Estiva — Item do cardápio | Single Post | Página individual de item do CPT |
| Estiva — Cartão de item Deck | Loop Item | Cartão reutilizável para Loop Grid |

No **Theme Builder**, revise e publique cabeçalho/rodapé com condição **Site inteiro**. Publique o Single com condição **Singular → Item do cardápio**. O tema registra as localizações header, footer, single e archive; a entrega testa os três primeiros com modelos reais. Não há um modelo de arquivo publicado automaticamente.

O cabeçalho e o rodapé iniciais usam `[estiva_header]` / `[estiva_footer]`, compartilhando a identidade e os menus nativos. Você pode substituí-los por widgets visuais do Pro. Os modelos publicados assumem suas localizações; quando o Pro é desativado, os fallbacks nativos voltam.

O Single usa **Post Title**, **Post Content** e o campo dinâmico real de preço da Estiva. A prévia inicial aponta para um item do Deck. Textos de preço/porção são lidos do post atual; não há valores fixos no template. O aviso de referência do impresso permanece no modelo.

### Dynamic Tag e Loop Grid

Em controles compatíveis do Pro, selecione **Tags dinâmicas → Estiva Cervejaria → Estiva — dado do cardápio** e escolha preço BRL, descrição curta, porção, unidade ou disponibilidade.

Publique também o modelo Loop Item. Para um Loop Grid, selecione o modelo **Estiva — Cartão de item Deck** e o **ID de consulta `estiva_deck`**. Essa consulta força o CPT de cardápio e a unidade Deck, preservando filtros adicionais. O teste incluiu um produto temporário de outra unidade e confirmou que ele não apareceu. O ID `estiva_cervejas` consulta o CPT das cervejas.

O Loop Grid é opcional; o cardápio principal mantém HTML semântico, busca e categorias sem depender do Pro. Nenhum widget pago ou chave de licença foi embutido no tema. Ativação de conta, atualizações, biblioteca em nuvem e outros serviços comerciais do Pro continuam sob gestão da sua instalação/licença.

## 4. Editar o cardápio Deck

Em **Cardápio Estiva**, edite título, conteúdo completo, categoria, imagem e o metabox de informações:

- Unidade obrigatória: Deck, Brewpub, Fábrica ou Beach Bar.
- Preço decimal BRL, com ponto ou vírgula; vazio mostra “Consulte a unidade”.
- Descrição curta, porção/peso/unidades, destaque, disponibilidade e ordem.

Cada item pertence a uma unidade. O Deck não replica preços das demais. Para o mesmo produto com preços diferentes por unidade, crie registros independentes. Unidade inválida/vazia não aparece no menu; desmarcar disponibilidade mantém o item com aviso. O conteúdo completo alimenta a página individual; a descrição curta alimenta os cartões.

O dataset inicial é do PDF Deck: todos os 23 itens, valores sujeitos a revisão, espetinhos agrupados com nota de ambiguidade e growler 1L sem preço. Não são preços atuais confirmados. Revise disponibilidade, alergênicos e valores antes de publicar comercialmente.

## 5. Dados e privacidade

Os CPTs ficam no tema para que um único ZIP funcione de forma independente. Trocar de tema preserva os registros no banco, mas sua interface depende de reativação ou migração para plugin. Não há exclusão na desativação.

Importadores exigem capacidade administrativa e nonce. Salvar campos exige `edit_post`, nonce válido, sanitização e proteção de autosave/revisão. A saída é escapada. Não há checkout, formulário próprio de coleta, reservas fictícias, rastreamento ou mapas embutidos. Serviços e plugins que você adicionar exigem revisão própria de privacidade. Revise o modelo legal antes da publicação.

As fontes locais Barlow e Barlow Condensed acompanham licenças OFL. As composições em CSS e o screenshot são originais e não representam fotografias reais das unidades ou logotipo oficial. A paleta é uma aproximação editável, não uma medição certificada do branding.

## 6. WP-CLI e ambiente de QA

No diretório do WordPress:

```sh
wp theme activate estiva-cervejaria
wp estiva seed
wp estiva elementor
wp estiva pro --user=SEU_ADMINISTRADOR # cria rascunhos
# Somente em QA, para aplicar os modelos globais de teste:
wp estiva pro --apply --user=SEU_ADMINISTRADOR
```

O checkout da nuvem já é isolado; não crie worktree sem pedido. `bash /workspace/WPSite/scripts/dev-up.sh` prepara os containers descartáveis `estiva-v3-*`, usando imagens fixadas por digest. PHP/WP-CLI rodam no container. Credenciais aleatórias e o pacote Pro privado ficam fora do repositório, em `/workspace/estiva-v3-runtime`; não compartilhe seus valores.

Se o Pro ainda não estiver instalado no QA, o script exige o ZIP oficial em `ESTIVA_PRO_ZIP` ou no arquivo privado padrão. Ele não procura distribuições alternativas nem altera verificações de licença/TLS. A cópia Pro fornecida nesta sessão foi utilizada somente para testes e não integra a entrega.

A rede bloqueou o site de referência e consultas de atualização WordPress.org. O QA define o locale `pt_BR` por configuração, sem fabricar pacotes de tradução; a interface administrativa pode usar o idioma de fallback. Na sua instalação, configure o idioma normalmente pelo WordPress.

Processos devem reiniciar em novas tarefas; a restauração de volumes/autenticação não deve ser presumida. `dev-up.sh` verifica o módulo Pro real, o cabeçalho publicado e o conteúdo HTTP do Deck. É um script de desenvolvimento, nunca de implantação em produção. Resultados e reprodução estão em `QA.md`.
