# Relatório de testes — Estiva v3

Execução em 28/10/2026, em instalações locais descartáveis. WordPress 7.1.3, PHP 8.3.35, MariaDB 11.4.13, Elementor 4.3.4 e Elementor Pro 4.3.0 fornecido pelo usuário. Nenhuma alteração foi aplicada ao site público ou à instalação local do usuário.

## Resultados

| Verificação executada | Resultado |
|---|---|
| Navegador Chromium, Pro com páginas Elementor | 107 verificações passaram |
| Navegador, somente Elementor gratuito | 98 verificações passaram |
| Navegador, sem Elementor | 98 verificações passaram |
| Navegador, instalação limpa do ZIP sem plugins | 98 verificações passaram |
| Runtime WordPress: dados, importação, campos, segurança e APIs Pro | 129 verificações passaram |
| Loop Grid Pro real, Dynamic Tags e isolamento do Deck | 18 verificações passaram |
| Editor Elementor: início, Deck, cabeçalho e rodapé | 4 documentos editados, publicados e restaurados pelo editor |
| axe-core 4.11.0, WCAG A/AA, 7 rotas em duas larguras | 14 varreduras sem violações detectadas |
| Upload e ativação pelo painel em instalação limpa | Passou; primeira importação 37, segunda 0 |
| Sintaxe PHP e estrutura obrigatória do tema | Passou, 18 arquivos PHP |

São 401 verificações de navegador nos quatro perfis finais. Larguras de 360, 768, 1280 e 1440 px; busca, filtros, menu por teclado, headings, idioma pt-BR, ausência de overflow, páginas, produto individual, fontes e 404. Theme Builder de cabeçalho, rodapé e Single foi exercitado com os modelos reais publicados. O suporte de archive está registrado, mas não foi validado com um modelo Pro próprio de arquivo.

Os testes runtime conferem os 23 produtos contra o dataset, importação idempotente, nonce, permissões, sanitização, XSS, valores decimais, disponibilidade, destaque, consultas e modelos Pro. As fixtures temporárias foram removidas. O teste Loop incluiu produto de outra unidade e confirmou sua exclusão. As modificações temporárias do editor foram restauradas.

## Evidências e reprodução

Resultados JSON, logs e capturas estão em `evidence/`. Os perfis finais são `pro-elementor`, `free`, `native` e `zip-native`. `installed-zip-verification.json` compara cada arquivo do ZIP com o código e com a instalação limpa. O ZIP completo contém os scripts, as fontes e este relatório; o ZIP do tema é o instalável no painel.

Execute `bash scripts/dev-up.sh` em um ambiente Docker de desenvolvimento com o ZIP Pro legítimo disponível no caminho privado descrito em INSTALL.md. Execute `python scripts/package.py` para empacotar. Os scripts de testes dependem de Python, Playwright/Chromium e axe-core; consulte seus imports e variáveis ESTIVA_*. `runtime-tests.php` deve ser executado via WP-CLI com usuário administrativo no contêiner de QA. `zip-install-env.py` exige um contêiner e tabelas de teste ainda não existentes. Não execute fixtures em produção.

## Limites e revisão antes de publicar

O acesso automatizado ao site público retornou HTTP 403 do proxy. Não houve auditoria visual ou editorial ao vivo; a versão usa os materiais fornecidos na skill, conforme source-audit.md. Preços do PDF são referências históricas e precisam de confirmação, assim como contatos, horários, endereços, fotos e texto de privacidade. Campos sem confirmação permanecem editáveis e sem dados inventados.

Os logs de instalação registraram avisos de conexão do núcleo aos serviços de atualização WordPress.org. Não foram desativadas verificações TLS ou de assinatura. Esses avisos externos não foram tratados como testes aprovados de atualização. O idioma de QA foi configurado como pt_BR; não se alega validação de pacote de tradução baixado.

Não foram testados Safari, leitor de tela humano, produção, envio de e-mail, pagamentos, ativação de licença, biblioteca em nuvem ou atualizações comerciais. As varreduras axe têm itens inconclusivos que pedem revisão humana e não constituem certificação de acessibilidade. O plugin Pro e sua licença não fazem parte dos ZIPs entregues; a integração usa o plugin já disponível na instalação de destino.
