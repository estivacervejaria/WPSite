# Estiva Cervejaria — v3 / Deck + Elementor Pro

Nova implementação institucional de 28/10/2026, com tema instalável, oito páginas, seis estilos de cerveja e cardápio Deck editável com os 23 itens do impresso fornecido.

- `dist/estiva-cervejaria.zip`: tema instalável via Aparência → Temas.
- `theme/estiva-cervejaria/`: fontes do tema.
- `docs/INSTALL.md`: instalação, edição e Theme Builder.
- `docs/source-audit.md`: evidências e limitações das fontes.
- `docs/QA.md`, `docs/evidence/`: resultados efetivamente executados nesta versão.
- `skills/estiva-wordpress/`: skill e referências originais.

A integração foi testada com Elementor 4.3.4 e Elementor Pro 4.3.0, usando o pacote Pro fornecido pelo usuário. O plugin e a licença Pro não fazem parte dos arquivos de distribuição. O tema também funciona sem Elementor.

A versão anterior foi preservada em `previous/v2/` e não integra a nova entrega. Os preços são referências do impresso Deck, sem vigência confirmada; não se aplicam às outras unidades.

`bash scripts/dev-up.sh` inicia o QA descartável. `python scripts/package.py` gera o ZIP do tema. Não execute os scripts de QA em produção.
