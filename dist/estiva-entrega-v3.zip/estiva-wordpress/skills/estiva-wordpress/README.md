# Estiva WordPress — Skill para Codex

Esta entrega é uma **skill que orienta o Codex a criar o tema**. **Não contém um tema WordPress já pronto**; o tema instalável será gerado quando a skill for executada em um projeto de desenvolvimento.

## Instalação no projeto
1. Extraia `estiva-wordpress-codex.zip`.
2. Copie `estiva-wordpress-codex/` para `<seu-projeto>/.agents/skills/estiva-wordpress/` (a pasta pode manter seu nome; a skill chama-se `estiva-wordpress`).
3. Abra esse projeto no Codex.
4. Use a solicitação: `Use a skill $estiva-wordpress para implementar o site completo da Estiva Cervejaria. Gere e teste o tema instalável, cardápio Deck e compatibilidade Elementor gratuito; entregue os ZIPs de dist e relatório QA.`

A skill inclui `SKILL.md`, referências de marca e transcrição do cardápio, anexos originais e um verificador de estrutura do tema. Os valores do PDF devem ser revisados antes da publicação.
