# Identidade, anexos e evidências

## Anexo institucional — `assets/estiva-institucional-referencia.png`
- Marca ESTIVA / Cerveja Artesanal / Santos.Brasil, estampada em copo e peça promocional.
- Cores perceptíveis: amarelo/mostarda, carvão/preto e branco. **Hex provisório para prototipagem:** amarelo `#F3C316`, preto `#111111`, branco `#FFFFFF`; não afirmar que são cores oficiais; validar com branding original.
- Texturas/gráficos: metal/contêiner, tipografia forte condensada e estilo manuscrito para mensagens; aspectos urbanos, aventura/liberdade e cerveja artesanal. Usar fontes de código aberto licenciadas ou alternativas do sistema; não extrair fontes proprietárias de anúncios.
- Frases apresentadas: “É novo no mundo Estiva?”, “Aqui você decide!”, “É como funciona?”, “Estiva onde estiver”. Revisar ortografia em reprodução editorial, sem alterar informações comerciais.
- Autosserviço citado: cadastro breve no caixa, cartão pré-pago, torneiras, servir a vontade, retornar cartão para visitas. Confirmação comercial pendente.
- Estilos ilustrados: Pilsner (sem glúten segundo folheto), American IPA, Hop Lager, Premium Lager, Chopp Black e Wine Beer. **Alegações de ‘sem glúten’ ou características técnicas exigem validação atual antes de publicar como fato.**
- Eventos: chopeiras, Bikebeer, Kombeer (confirmar serviços atuais e condições).

## PDF Deck — `assets/cardapio-deck-referencia.pdf`
- Uma página, cardápio “Estiva Deck”, organização por Petiscos, Espetinhos, Combos, Snacks, Bebidas não alcoólicas e Growler 1L.
- Nota no rodapé: Estiva Beach Bar, quiosque de praia Canal 3 em Santos e 6 torneiras (alegações possivelmente datadas; solicitar confirmação).
- Data inferível do nome original do arquivo: “16.09”, SEM ano explícito — não atribuir data de vigência.
- Transcrição estruturada em `menu-data.md`. O cardápio deve ser recriado em HTML de fácil leitura, não como imagem estática.

## Referências web fornecidas pelo usuário
- `https://estivacervejaria.com.br/` — conferir site institucional e informação atual antes de sobrescrever.
- `https://www.instagram.com/estivacervejaria/` — conferir feed/identidade quando acessível e com permissão; não assumir acesso à API privada.
- `https://brewery.nicdark.com/?storefront=envato-elements` — benchmark visual; não copiar código/arte/arquivos.

## Escopo de confirmação humana
Obter arquivos de logo em vetor/transparente, endereços/horários atuais por unidade, contatos, links WhatsApp, fotos com licença, lista de estilos ativos, validade de preços, LGPD e texto de privacidade. Criar controles no admin para atualização sem código.
