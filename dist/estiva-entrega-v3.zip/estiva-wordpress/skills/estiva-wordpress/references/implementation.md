# Arquitetura técnica e execução

## Organização sugerida
```
wp-content/themes/estiva-cervejaria/
  style.css functions.php index.php front-page.php page.php single.php archive.php
  header.php footer.php 404.php screenshot.png
  page-templates/template-full-width.php
  page-templates/template-cardapio.php
  template-parts/...
  inc/setup.php inc/assets.php inc/customizer.php inc/menu-cpt.php inc/meta-boxes.php inc/elementor.php inc/seed.php
  assets/css/main.css assets/js/main.js assets/images/...
  languages/
```
Prefira separar conteúdo de negócio e tema em plugin `estiva-core` se gerar CPT persistente e importação, entregando segundo ZIP opcional. Se usar CPT no tema por simplicidade, informe que ao trocar tema sua UI de edição deixa de existir.

## Elementor
- Tema deve operar sem Elementor, renderizando página via `the_content()`.
- Com Elementor Free ativado, editar páginas padrão e templates de largura total; tipografia/cores globais nativas; não exigir Theme Builder Pro.
- Registrar localizações para cabeçalho/rodapé via API Elementor Theme Locations somente se disponível e apropriada. Não substituir conteúdo por HTML fixo quando o Elementor estiver editando.
- Pro pode sobrepor cabeçalho/rodapé via Theme Builder futuramente; não incorporar plugin, widgets pagos ou licenças.

## Informação estruturada
Armazenar preço em decimal invariável, formatar com `number_format_i18n`/locale pt_BR; separar descrição curta, ingredientes, alergênicos não confirmados e observações. Oferecer flag de indisponibilidade sem apagar item. Alimentar menu via dataset fonte (`references/menu-data.md`) e importador idempotente; nunca registrar preço como hardcode nos templates.

## Conjunto mínimo de testes
- `php -l` em todos `.php`.
- `unzip -t` no ZIP final e checar diretório raiz.
- `scripts/check-theme.sh wp-content/themes/estiva-cervejaria` do pacote da skill.
- `wp theme activate estiva-cervejaria` em WordPress de teste; ver site sem Elementor.
- Com Elementor Free: criar/editar homepage e cardápio sem destruir estilos e layout.
- Revisar largura mobile 360 px, 768 px, desktop 1280 px, navegação por teclado, header sticky se houver, contraste, links e âncoras.
- Registrar evidências de teste efetivas e lacunas. Não alegar teste de runtime se não houver WordPress executável.

## Organização de entrega
`dist/estiva-cervejaria.zip`, opcional `dist/estiva-core.zip`, `docs/INSTALL.md`, `docs/source-audit.md`, `docs/QA.md`. Deixar tudo em diretório compartilhável; nomear arquivos sem espaços quando possível.
