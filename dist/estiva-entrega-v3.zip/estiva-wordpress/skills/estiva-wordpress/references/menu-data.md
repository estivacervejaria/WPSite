# Dados de referência — cardápio Estiva Deck

Fonte: página única do PDF em `assets/cardapio-deck-referencia.pdf`. Transcrição assistida; revisão de itens, unidades e valores necessária antes de publicar. Moeda: BRL. Não extrapolar para Beach Bar ou Brewpub.

| Categoria | Item | Preço (R$) | Observação no material |
|---|---|---:|---|
| Petiscos | Dadinho de tapioca | 47 | 300 g; acompanha geleia de pimenta |
| Petiscos | Calabresa acebolada | 46 | 400 g; calabresa em rodelas salteadas com cebola |
| Petiscos | Costela desfiada | 149 | 450 g; cozimento lento, queijo derretido, fatias de pão |
| Petiscos | Salame artesanal | 75 | 400 g; salame italiano artesanal fatiado |
| Petiscos | Isca de frango | 59 | 400 g; tiras empanadas; maionese de alho assado |
| Petiscos | Fritas | 45 | 400 g; batata frita palito |
| Petiscos | Fritas Estiva | 59 | 400 g; cheddar cremoso e bacon crocante |
| Petiscos | Kibe com queijo | 35 | 8 unidades; massa de trigo, carne, especiarias, muçarela |
| Petiscos | Coxinha de costela | 42 | 8 unidades; massa de batata, costela bovina |
| Petiscos | Bolinho de salmão | 42 | 8 unidades; batata, salmão, cream cheese, cebolinha |
| Petiscos | Croquete vegetariano | 42 | 8 unidades; brócolis, alho, muçarela |
| Espetinhos | Espetinhos (carne, frango, coalho, coração, kafta, linguiça) | 15 | Valor apresentado para conjunto de sabores; confirmar preço por sabor |
| Espetinhos | Pão de alho | 12 | Unidade |
| Combos | Combo 1 | 80 | 2 linguiça, 2 carne, 2 pães de alho; maionese de alho, vinagrete e farofa |
| Combos | Combo 2 | 108 | 2 queijo coalho, 2 carne, 2 frango, 2 pães de alho; maionese de alho, vinagrete e farofa |
| Snacks | Amendoim artesanal | 12 | 100 g |
| Snacks | Piporka Skin artesanal | 15 | 200 g |
| Snacks | Provolone chips | 39 | tradicional ou lemon pepper |
| Bebidas não alcoólicas | Água mineral | 5 | com ou sem gás |
| Bebidas não alcoólicas | Suco lata | 7 | — |
| Bebidas não alcoólicas | Refrigerante | 7 | — |
| Bebidas não alcoólicas | H2O | 9 | — |
| Growler | Growler 1L | — | Delivery ou take away; preço não indicado |

**Importante:** Os preços representam o impresso fornecido, não preços confirmados vigentes. O PDF apresenta uma ambiguidade tipográfica nos espetinhos: R$15 junto ao grupo de sabores, não preço individual explicitamente vinculado a cada sabor. Criar como um produto com variações de sabor até confirmação. Não mostrar preço para growler.

## Cervejas presentes no folheto institucional (sem tabela de preços)
Pilsner, American IPA, Hop Lager, Premium Lager, Chopp Black, Wine Beer. Descrições e ícones de amargor/corpo não são dados numéricos para cálculo de IBU ou ABV. Não adicionar métricas fictícias nem preços.
