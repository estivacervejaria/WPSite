---
name: estiva-wordpress
description: Desenvolve, refatora, testa e empacota o tema WordPress instalável da Estiva Cervejaria, com identidade visual preta/amarela, Elementor Free (preparado para Pro), catálogo/cardápio editável, páginas de unidades e experiência responsiva. Use para tarefas de website, landing page, tema, Elementor e cardápio da Estiva.
---

# Skill: Estiva Cervejaria — Tema WordPress

Você é desenvolvedor WordPress sênior, designer UI/UX e especialista em Elementor. Trabalhe no repositório ativo e ENTREGUE CÓDIGO EXECUTÁVEL, não apenas mockups ou sugestões. Idioma editorial: português brasileiro.

## Fontes obrigatórias e prioridade
1. Leia `references/brand-and-sources.md` para a identidade e a interpretação fiel dos dois anexos incluídos em `assets/`.
2. Leia `references/menu-data.md` ANTES de preencher o cardápio. Preserve unidades, descrições e preços documentados; preços não confirmados devem ser tratados como sujeitos a revisão.
3. Leia `references/implementation.md` para arquitetura, requisitos e definição de pronto.
4. Se houver acesso à internet, visite `https://estivacervejaria.com.br`, `https://www.instagram.com/estivacervejaria/` e `https://brewery.nicdark.com/?storefront=envato-elements`. Registre quando algum estiver inacessível; NÃO alegue ter auditado conteúdo indisponível. Extraia paleta, tipografia, organização de seções e linguagem com evidência. A terceira URL é referência de layout/UX, não fonte de código, arte ou licenças. Nunca copie tema, imagens, CSS, HTML ou assets proprietários.
5. Imagens dos anexos são REFERÊNCIAS visuais, não banners ideais de web: não publicar fotografias legíveis do cardápio como substituto de HTML acessível. Sem inventar logotipos ou arquivos originais. Sempre oferecer substituição no painel.

## Missão e entregas obrigatórias
- Criar um tema clássico/híbrido WordPress ORIGINAL chamado `estiva-cervejaria` que seja instalável via **Aparência > Temas > Adicionar tema > Enviar tema** (ZIP contendo a pasta do tema), com `style.css` cabeçalho válido, `functions.php`, templates de fallback, screenshot próprio e sem erros fatais.
- Compatível com WordPress estável suportado, PHP moderno e Elementor **Free**; deve funcionar sem Elementor (fallback nativo). Preparar áreas opcionais e CSS para Elementor Pro, sem depender de widgets Pro e sem alegar licença incluída.
- Criar páginas iniciais com conteúdo demonstrativo em instalação controlada ou comando WP-CLI idempotente: **Início**, **Cervejas**, **Cardápio Deck**, **Unidades**, **Eventos**, **Sobre**, **Contato** e **Política de Privacidade** (esta com modelo a revisar, não aconselhamento jurídico).
- Homepage responsiva premium: hero imersivo, chamadas para cardápio e unidades, filosofia de liberdade/autosserviço, estilos de cervejas, eventos, ambientes, contatos/Instagram; navegação mobile acessível, CTA de WhatsApp configurável (sem número inventado).
- Página `/cardapio-deck/` em HTML semântico com categorias, descrição, preço em BRL, busca/filtro opcional, aviso de alteração de preço e botões configuráveis. Todos os itens do PDF devem constar; não usar o próprio PDF como único cardápio.
- Estrutura editável no admin: custom post type `estiva_menu_item` com taxonomia `estiva_menu_category`, campos (preço, descrição, peso/unidades, destaque, unidade, disponível, ordem), nonce/capabilities, validação/sanitização/escaping. Se decidir criar plugin complementar para preservar dados quando o tema mudar, justifique e entregue ambos ZIPs, deixando o tema funcional independentemente.
- Cervejas com estilos clássicos identificados no folheto institucional: Pilsner, American IPA, Hop Lager, Premium Lager, Chopp Black e Wine Beer. Criar páginas/cartões editáveis para estilos e outros que sejam confirmados. Não inventar ABV, IBU ou disponibilidade atual.
- Template amigável ao Elementor: `elementor_theme_do_location` quando disponível e fallbacks, `the_content()`, `wp_head()`, `wp_footer()`, suporte `title-tag`, thumbnails, custom-logo, menus, editor-styles, alinhamentos e CSS variables; modelo de página largura total e canvas (sem sobrescrever o plugin).
- Customizer ou opções nativas para logomarca, paleta, banners, endereços, links, WhatsApp, Instagram, horários, URLs e textos. Deixar campos vazios quando não confirmados. Jamais codificar tokens secretos.
- Entregar `dist/estiva-cervejaria.zip`, documentação de instalação, importação de cardápio, edição Elementor Free, permissões, limites e relatório de testes. Incluir arquivos-fonte e um script de validação.

## Restrições inegociáveis
- Identidade primária dos anexos: preto/carvão + amarelo dourado, branco de alto contraste, textura industrial moderada, estética portuária/urbana/praia. **Não afirmar hex oficial** sem medição/validação; valores em CSS são aproximações facilmente ajustáveis.
- Respeitar a distinção entre Brewpub/Fábrica/Deck/Beach Bar; o PDF entregue corresponde a **Deck**. Não propagar automaticamente seus preços para outras unidades.
- Comunicar autosserviço por cartão pré-pago, cadastro no caixa, escolha do chopp nas torneiras e cartão utilizável em filiais **somente como referência histórica do impresso**, sujeita a confirmação de operação atual.
- Não copiar visual 1:1 do template Nicdark; inspirar-se em hierarquia, ritmo visual, seções e responsividade, mantendo implementação autoral.
- Sem paywall, sem framework comercial, sem dependências CDN obrigatórias, sem formulário de pagamento próprio, sem inventar reservas, avaliações, lojas, localizações ou políticas comerciais.
- Acessibilidade WCAG 2.2 AA onde aplicável, SEO técnico, performance (lazy-loading, WebP se possível, imagens dimensionadas), textos ALT, navegação por teclado, contraste, metatags via plugins SEO compatíveis, LGPD e cookie consent apenas quando necessário e implementado corretamente.
- Segurança WordPress: `ABSPATH`, nonces, capability checks, sanitização de inputs, escaping de outputs, SQL parametrizado, sem importar conteúdo remoto não confiável, `wp_enqueue_*`, prefixos `estiva_` em funções/classes/meta.

## Procedimento de execução
1. Inspecione o diretório; se existir site, verifique dependências e faça alterações incrementais sem apagar trabalho do usuário. Informe plano curto e lacunas documentais.
2. Confira fontes e crie `docs/source-audit.md` com evidência, limitações e decisões de design. Leia os materiais citados nesta skill.
3. Desenhe arquitetura e implemente todos os templates, componentes, estilos, JS, modelos e dados de exemplo em arquivos reais. Sempre produzir logo o primeiro incremento funcional antes de refinamentos.
4. Execute importação idempotente por WP-CLI ou rotina administrativa opt-in; jamais criar páginas/itens duplicados a cada ativação.
5. Teste responsividade 360/768/1280/1440px, teclado, links, avisos PHP, ativação sem Elementor, com Elementor Free, cardápio em mobile, escaping, fixtures e upload do ZIP. Se WordPress/Elementor não estiverem disponíveis, marque testes como NÃO EXECUTADOS (não como aprovados).
6. Empacote com pasta-raiz correta; valide `unzip -t` e rode `scripts/check-theme.sh` sobre a pasta do tema. Entregue ZIP e caminho, comandos de instalação, recursos implementados, pendências e testes executados.

## Critérios de aceitação
O trabalho NÃO está concluído apenas com uma landing page estática, screenshot, prompt, README ou skeleton. Concluído significa tema WordPress carregável, com renderização funcional, home, páginas, cardápio editável, integração Elementor Free opcional, conteúdo inicial fiel, arquivos de distribuição e registro explícito de testes. Se o contexto operacional impedir a entrega, informe exatamente qual bloqueio ocorreu e entregue o incremento validado sem declarar conclusão total.
