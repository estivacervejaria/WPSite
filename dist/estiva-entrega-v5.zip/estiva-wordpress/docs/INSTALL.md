# Atualização v5 — manutenção e acervo real

## Publicar a página de manutenção

1. Envie o ZIP **estiva-cervejaria-v5.zip** em Aparência → Temas → Adicionar novo → Enviar tema. Confirme a substituição do tema anterior. O ZIP inclui as fotos e tem aproximadamente 13 MB: o limite de upload do servidor precisa comportá-lo (32 MB é suficiente). O pacote completo de fontes não é instalável como tema.
2. Acesse o painel como administrador. As páginas ausentes são criadas, incluindo **Manutenção**; agora são nove. Conteúdo de páginas existentes e a escolha de uma página inicial existente são preservados.
3. Abra **Aparência → Manutenção Estiva**. Revise título e mensagem, marque **Ativar manutenção para visitantes** e salve.
4. Limpe os caches do servidor, de plugins e da CDN. Teste em uma janela anônima: visitantes devem ver a manutenção. Administradores e editores autenticados continuam acessando o site completo; login e painel permanecem disponíveis.
5. A página mostra a identidade Estiva, a foto do pôr do sol enviado, Brewpub/Fábrica na Ana Costa, quiosque no Canal 3, Instagram e **faleconosco@estivacervejaria.com.br**. Instagram, e-mail público e WhatsApp são configurados em Personalizar. WhatsApp aparece apenas se uma URL for informada.
6. O modo retorna HTTP **503**, Retry-After de 3600 segundos, instruções noindex e cabeçalhos de não cache. Bloqueia também a API REST pública e os feeds/sitemaps do site; usuários com capacidade de editar páginas podem trabalhar. Trata-se de manutenção do frontend do WordPress, não de autenticação de arquivos de upload ou de um firewall. Arquivos estáticos e o login continuam acessíveis.
7. Para reabrir o site, desmarque o controle, salve, limpe os caches e confira novamente em janela anônima. O modo é entregue **desativado**, para não ocultar um site sem uma escolha no painel. Não há expiração automática.

A página `/manutencao/` pode ser visualizada com HTTP 200 e noindex mesmo quando o modo está desligado. O modo ativo protege todas as páginas públicas com a apresentação de manutenção; não depende de definir Manutenção como página inicial. Na v5, essa página é um documento nativo e não entra no importador Elementor: seus textos têm edição própria no painel.

## Fotos e vídeo

O tema já inclui 22 fotos convertidas para WebP responsivo e um vídeo curto do quiosque em MP4/H.264, sem áudio, sem autoplay e com preload desativado. Não precisa de HEIC no servidor nem de importação para que apareçam. As conversões preservam o conteúdo e a orientação; não foram geradas imagens de estabelecimentos. Metadados EXIF/GPS não integram os arquivos publicados.

- Início: foto real do Brewpub no destaque, unidades e eventos com fotos.
- Unidades: Brewpub e Fábrica juntos na Ana Costa; quiosque na praia do Canal 3. Galerias separadas de Brewpub, Fábrica e quiosque.
- Eventos: cinco registros fornecidos, sem anunciar datas ou programação futura.
- Sobre: foto da fábrica e memória da antiga loja Praiamar, encerrada no início de 2026, com seis fotos. Ela não é exibida como unidade ativa.

**Aparência → Acervo Estiva → Importar acervo para a biblioteca** copia os arquivos otimizados para a biblioteca, permitindo selecioná-los nos widgets Elementor. São 24 mídias: 22 fotos, um pôster e um vídeo. A segunda execução não duplica os arquivos. Imagens próprias já existentes não são substituídas. O acervo embutido continua sendo o fallback se uma cópia importada for removida.

Em **Personalizar → Estiva — identidade e conteúdo**, substitua as imagens principais por anexos da biblioteca. Em **Estiva — galerias de fotos**, escolha os IDs dos anexos separados por vírgulas, na ordem desejada; vazio mantém a seleção incluída. Textos alternativos das cópias importadas podem ser editados na biblioteca.

Os vídeos **Estiva_Copa.MP4** e **Praiamar 5.MP4** não puderam ser transferidos: cada arquivo excede o limite de 32 MiB da ferramenta de anexos. Não foram incluídos nem testados. Versões menores podem ser integradas numa revisão posterior. Os originais HEIC/MOV ficam preservados fora dos pacotes; o site usa apenas os derivados otimizados. As imagens inline sem arquivo local não foram extraídas artificialmente.

A história detalhada (fundação, fundadores e marcos) ainda depende de texto aprovado. Apenas o fechamento do Praiamar em 2026 e a localização conjunta de Brewpub/Fábrica foram acrescentados como novos fatos confirmados pelo usuário. Valores e ofertas visíveis em fotos antigas não são apresentados como preços atuais.

---

## Recursos da revisão anterior (v4)

# Atualização v4 — páginas e contato

1. Faça backup do banco e de wp-content da instalação de destino.
2. Em Aparência → Temas → Adicionar novo → Enviar tema, envie o ZIP v4. Como a pasta permanece `estiva-cervejaria`, confirme a substituição da versão anterior. Não instale o ZIP da entrega completa como tema.
3. Com o tema ativo, acesse o painel como administrador. A versão v4 cria automaticamente somente as páginas ausentes: Início, Cervejas, Cardápio Deck, Unidades, Eventos, Sobre, Contato e Política de Privacidade. Preserva corpos de páginas existentes, mídias, produtos e uma página inicial já configurada. Se não houver página inicial configurada, define Início.
4. Confira Páginas → Todas as páginas. O conteúdo dinâmico é editado em Aparência → Personalizar → Estiva — identidade e conteúdo; as páginas também podem ser editadas pelo Elementor. A página Sobre antiga com `[estiva_about]` e a de Contato com `[estiva_contact]` recebem a apresentação atualizada sem regravar seu conteúdo.
5. Envie as fotos reais em Personalizar: **Foto real do PUB na Avenida Ana Costa**, **Foto real do quiosque no Canal 3**, além da foto da história, se houver. Sem fotos, a unidade mostra um espaço identificado como foto em preparação. Nenhuma foto de outro estabelecimento foi usada. Os dois lugares foram confirmados pelo usuário; número, horários e links específicos continuam editáveis.
6. Edite **História da Estiva** e **Título da página Sobre** com o histórico aprovado. O texto inicial apenas apresenta Santos e as duas unidades; não contém ano de fundação, nomes de fundadores ou marcos não confirmados.
7. O destinatário padrão do formulário é **faleconosco@estivacervejaria.com.br**, confirmado pelo usuário. Pode ser alterado em **Destinatário do formulário**. Se esse campo for apagado, a rotina usa o e-mail público configurado e, por último, o e-mail administrativo do WordPress. Confira o destino antes de abrir o site ao público.
8. Configure o serviço de e-mail/SMTP do servidor por meio do provedor ou de um plugin adequado. O tema usa `wp_mail`, mantendo o remetente do servidor e usando o visitante apenas em Reply-To. A confirmação indica que o WordPress aceitou o encaminhamento; não comprova entrega na caixa de entrada. Faça um teste real autorizado após configurar SPF/DKIM/DMARC com o provedor. Nenhuma senha SMTP deve ser colocada no tema.
9. Revise a Política de Privacidade para contemplar formulário, provedor, retenção e canal dos titulares. O formulário solicita nome, e-mail, assunto, mensagem e ciência de privacidade; não inscreve em marketing. O tema não arquiva as mensagens no banco, mas os provedores ou plugins podem mantê-las. O limitador guarda hash salgado do IP e contador temporário, não o IP original. Exclua a página /contato/ do cache de páginas/CDN para não congelar nonces; o tema já envia cabeçalhos de não cache nessa rota.
10. O cardápio e as cervejas continuam em **Aparência → Importar conteúdo Estiva**. Em instalação nova, depois das oito páginas automáticas, o importador adiciona 29 conteúdos (23 produtos + 6 estilos); a segunda execução retorna zero. Preços permanecem referências do PDF, sujeitos a confirmação.

O Instagram padrão é https://www.instagram.com/estivacervejaria/. O formulário oferece sugestão, reclamação, elogio, dúvida e outro assunto. Usa validação, nonce, campo antispam e limite de cinco tentativas válidas por identificador de rede em dez minutos. Não substitui proteção antispam do servidor em produção.

## Migração de servidor

Esta entrega prepara o tema e as páginas; não executa mudança de DNS, banco de produção ou contas de e-mail. Para reproduzir fielmente o site atual, ainda são necessários o texto aprovado da história e as fotos das duas unidades, ou uma exportação/backup autorizado do site atual com suas mídias. O acesso remoto ao site continua bloqueado por HTTP 403 neste ambiente.

Prepare uma instalação de testes no novo servidor, restaure banco/uploads/plugins conforme seu plano de migração, atualize as URLs usando ferramenta compatível com dados serializados, confira HTTPS, permalinks, menu, mídia, Elementor e e-mail. Preserve backups e valide tudo antes de trocar DNS. Não há cópia de licença ou binário do Elementor Pro neste pacote.

---

## Referência de edição Elementor e recursos herdados

# Instalação e uso

## 1. Instalar o tema

Esta versão foi feita para uma instalação nova de testes, conforme o pedido. Requisitos do tema: WordPress 6.8+ e PHP 8.1+. Testado com WordPress 7.1.3 e PHP 8.3.35.

1. Mantenha **Elementor** e **Elementor Pro** ativos na sua instalação. O teste usou Core 4.3.4 / Pro 4.3.0. O ZIP do tema não substitui nem inclui o plugin Pro ou a licença que você já possui.
2. Em **Aparência → Temas → Adicionar tema → Enviar tema**, envie `estiva-cervejaria.zip`, instale e ative.
3. Em **Aparência → Importar conteúdo Estiva**, clique **Importar conteúdo**. Isso cria oito páginas, seis cervejas e 23 itens exclusivamente no Deck. A ativação não importa nada silenciosamente. Repetir a importação cria zero registros quando os conteúdos já existem.
4. Em **Configurações → Leitura**, confirme Início como página inicial. O importador só faz isso se nenhuma home estiver configurada. Em **Links permanentes**, salve “Nome do post”. Configure o idioma do site como **Português do Brasil** em Geral.
5. Em **Aparência → Personalizar**, configure logo, paleta, textos principais, imagens, Instagram, e-mail, WhatsApp e endereço/horário/link de cada unidade. Os campos desconhecidos ficam vazios. Use imagens próprias/licenciadas e preencha o texto alternativo.
6. Se quiser menus personalizados, atribua-os às posições Principal e Rodapé. Sem menu principal atribuído, a navegação institucional funciona por fallback.

Páginas iniciais: Início, Cervejas, Cardápio Deck, Unidades, Eventos, Sobre, Contato e Política de Privacidade. A política é um modelo pendente de revisão, não aconselhamento jurídico.

## 2. Preparar as páginas Elementor

Em **Aparência → Preparar Elementor**, prepare as sete páginas originais. A política permanece nativa. A ação preserva páginas cujo conteúdo já foi personalizado e dados Elementor existentes.

Use **Editar com Elementor** para mover/remover os blocos e acrescentar widgets. Os blocos dinâmicos consultam os dados atuais do WordPress, em vez de manter uma cópia estática dos preços no layout. O hero já contém o H1: evite duplicá-lo ao adicionar títulos.

Shortcodes: `[estiva_hero]`, `[estiva_home]`, `[estiva_about]`, `[estiva_beers]`, `[estiva_deck_intro]`, `[estiva_menu]`, `[estiva_units]`, `[estiva_events]`, `[estiva_contact]`. O padrão de `[estiva_menu]` é exclusivamente Deck. No widget Shortcode, use Aplicar/Apply quando o controle aparecer e Atualizar/Publicar para salvar.

Textos gerais e identidade vêm do Customizer. Para criar conteúdo totalmente personalizado, substitua um bloco dinâmico por widgets Heading/Text Editor/Imagem. Cervejas são editadas no CPT Cervejas. Produtos e preços são editados no painel do cardápio.

Modelos nativos disponíveis: Largura total e Canvas. O canvas oficial do Elementor continua disponível e não é sobrescrito. Ao desativar os plugins, os shortcodes salvos continuam funcionando; o tema restaura os cabeçalhos/rodapés nativos e evita H1 duplicado.

## 3. Integração Elementor Pro / Theme Builder

Abra **Aparência → Modelos Elementor Pro** e clique **Criar modelos em rascunho**. São criados quatro modelos, sem alterar a licença ou publicar condições automaticamente:

| Modelo | Tipo | Uso |
|---|---|---|
| Estiva — Cabeçalho | Header | Cabeçalho compartilhado |
| Estiva — Rodapé | Footer | Rodapé compartilhado |
| Estiva — Item do cardápio | Single Post | Página individual de item do CPT |
| Estiva — Cartão de item Deck | Loop Item | Cartão reutilizável para Loop Grid |

No **Theme Builder**, revise e publique cabeçalho/rodapé com condição **Site inteiro**. Publique o Single com condição **Singular → Item do cardápio**. O tema registra as localizações header, footer, single e archive; a entrega testa os três primeiros com modelos reais. Não há um modelo de arquivo publicado automaticamente.

O cabeçalho e o rodapé iniciais usam `[estiva_header]` / `[estiva_footer]`, compartilhando a identidade e os menus nativos. Você pode substituí-los por widgets visuais do Pro. Os modelos publicados assumem suas localizações; quando o Pro é desativado, os fallbacks nativos voltam.

O Single usa **Post Title**, **Post Content** e o campo dinâmico real de preço da Estiva. A prévia inicial aponta para um item do Deck. Textos de preço/porção são lidos do post atual; não há valores fixos no template. O aviso de referência do impresso permanece no modelo.

### Dynamic Tag e Loop Grid

Em controles compatíveis do Pro, selecione **Tags dinâmicas → Estiva Cervejaria → Estiva — dado do cardápio** e escolha preço BRL, descrição curta, porção, unidade ou disponibilidade.

Publique também o modelo Loop Item. Para um Loop Grid, selecione o modelo **Estiva — Cartão de item Deck** e o **ID de consulta `estiva_deck`**. Essa consulta força o CPT de cardápio e a unidade Deck, preservando filtros adicionais. O teste incluiu um produto temporário de outra unidade e confirmou que ele não apareceu. O ID `estiva_cervejas` consulta o CPT das cervejas.

O Loop Grid é opcional; o cardápio principal mantém HTML semântico, busca e categorias sem depender do Pro. Nenhum widget pago ou chave de licença foi embutido no tema. Ativação de conta, atualizações, biblioteca em nuvem e outros serviços comerciais do Pro continuam sob gestão da sua instalação/licença.

## 4. Editar o cardápio Deck

Em **Cardápio Estiva**, edite título, conteúdo completo, categoria, imagem e o metabox de informações:

- Unidade obrigatória: Deck, Brewpub, Fábrica ou Beach Bar.
- Preço decimal BRL, com ponto ou vírgula; vazio mostra “Consulte a unidade”.
- Descrição curta, porção/peso/unidades, destaque, disponibilidade e ordem.

Cada item pertence a uma unidade. O Deck não replica preços das demais. Para o mesmo produto com preços diferentes por unidade, crie registros independentes. Unidade inválida/vazia não aparece no menu; desmarcar disponibilidade mantém o item com aviso. O conteúdo completo alimenta a página individual; a descrição curta alimenta os cartões.

O dataset inicial é do PDF Deck: todos os 23 itens, valores sujeitos a revisão, espetinhos agrupados com nota de ambiguidade e growler 1L sem preço. Não são preços atuais confirmados. Revise disponibilidade, alergênicos e valores antes de publicar comercialmente.

## 5. Dados e privacidade

Os CPTs ficam no tema para que um único ZIP funcione de forma independente. Trocar de tema preserva os registros no banco, mas sua interface depende de reativação ou migração para plugin. Não há exclusão na desativação.

Importadores exigem capacidade administrativa e nonce. Salvar campos exige `edit_post`, nonce válido, sanitização e proteção de autosave/revisão. A saída é escapada. Há formulário de contato, descrito no início deste guia. Não há checkout, reservas fictícias, rastreamento ou mapas embutidos. Serviços e plugins que você adicionar exigem revisão própria de privacidade. Revise o modelo legal antes da publicação.

As fontes locais Barlow e Barlow Condensed acompanham licenças OFL. As composições em CSS e o screenshot são originais e não representam fotografias reais das unidades ou logotipo oficial. A paleta é uma aproximação editável, não uma medição certificada do branding.

## 6. WP-CLI e ambiente de QA

No diretório do WordPress:

```sh
wp theme activate estiva-cervejaria
wp estiva seed
wp estiva elementor
wp estiva pro --user=SEU_ADMINISTRADOR # cria rascunhos
# Somente em QA, para aplicar os modelos globais de teste:
wp estiva pro --apply --user=SEU_ADMINISTRADOR
```

O checkout da nuvem já é isolado; não crie worktree sem pedido. `bash /workspace/WPSite/scripts/dev-up.sh` prepara os containers descartáveis `estiva-v3-*`, usando imagens fixadas por digest. PHP/WP-CLI rodam no container. Credenciais aleatórias e o pacote Pro privado ficam fora do repositório, em `/workspace/estiva-v3-runtime`; não compartilhe seus valores.

Se o Pro ainda não estiver instalado no QA, o script exige o ZIP oficial em `ESTIVA_PRO_ZIP` ou no arquivo privado padrão. Ele não procura distribuições alternativas nem altera verificações de licença/TLS. A cópia Pro fornecida nesta sessão foi utilizada somente para testes e não integra a entrega.

A rede bloqueou o site de referência e consultas de atualização WordPress.org. O QA define o locale `pt_BR` por configuração, sem fabricar pacotes de tradução; a interface administrativa pode usar o idioma de fallback. Na sua instalação, configure o idioma normalmente pelo WordPress.

Processos devem reiniciar em novas tarefas; a restauração de volumes/autenticação não deve ser presumida. `dev-up.sh` verifica o módulo Pro real, o cabeçalho publicado e o conteúdo HTTP do Deck. É um script de desenvolvimento, nunca de implantação em produção. Resultados e reprodução estão em `QA.md`.
