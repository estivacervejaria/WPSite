# Fontes v5 — 11/11/2026

O usuário enviou acervo separado por Eventos, Brewpub, Fábrica, Quiosque e Praiamar. Confirmou que Brewpub e Fábrica ficam juntos na Avenida Ana Costa e que a loja do Shopping Praiamar foi fechada no início do ano (2026). Essas informações prevalecem sobre o escopo anterior. Praiamar aparece somente como memória de unidade encerrada, nunca como unidade aberta, local de visita ou cardápio vigente.

Foram transferidos e inspecionados 22 arquivos HEIC e Quiosque 3.MOV (1,27 s). As conversões técnicas para WebP 480/960/1600 e MP4/H.264 preservam o conteúdo visual e a orientação. EXIF/GPS não são publicados; o vídeo ambiente foi exportado sem áudio. Arquivos de mídia em assets/media são derivados reais fornecidos pelo usuário, não conteúdo gerado. O catálogo contém nome da fonte, SHA256, dimensões, grupo e texto alternativo. Os originais ficam fora do repositório e do pacote; thumbnails WebP e arquivos do tema compõem a distribuição.

Dois vídeos não foram transferidos: Estiva_Copa.MP4 e Praiamar 5.MP4 excedem 32 MiB, limite da ferramenta de anexos. Não há alegação de conversão ou teste desses vídeos. As imagens inline adicionais foram vistas na conversa, mas não havia caminho local para incorporá-las; não foram recriadas ou atribuídas a arquivos diferentes.

O site público, Instagram e a referência Nicdark continuam bloqueados com HTTP 403 pelo proxy; as fontes do conteúdo visual novo são os anexos e as confirmações do usuário. Não foram copiados textos ou imagens de terceiros. Nenhum preço, ABV, IBU, horário ou número de endereço foi extraído das telas fotografadas para virar dado comercial atual.

Manutenção foi solicitada nesta revisão: identidade, informações essenciais e contatos. O destinatário já confirmado permanece faleconosco@estivacervejaria.com.br; nenhum WhatsApp foi inventado. Não houve intervenção no servidor de produção, no DNS ou na instalação local do usuário.

---

## Registro das revisões anteriores

# Atualização de fontes — v4

Em 28/10/2026, o usuário confirmou PUB na Avenida Ana Costa, quiosque na praia do Canal 3 e destinatário faleconosco@estivacervejaria.com.br. As unidades públicas desta revisão mostram esses dois locais. Identificadores legados de Fábrica/Deck/Beach Bar nos produtos não foram removidos, unidos ou remapeados.

Novo acesso ao site institucional, domínio www, Instagram e referência Nicdark retornou HTTP 403 do proxy. Nenhum texto nem fotografia do site atual pôde ser recuperado. A página Sobre tem apresentação breve com fatos confirmados; não é uma transcrição nem uma história completa. Fundação, fundadores, cronologia e fotos reais permanecem pendentes de fornecimento. O conteúdo institucional da skill continua como referência, sem converter alegações históricas em operações atuais.

O formulário novo usa exclusivamente o destinatário confirmado ou configuração administrativa; não foi enviado e-mail externo durante os testes. As fotos têm controles separados na biblioteca de mídia; não foram fabricadas imagens de estabelecimentos reais. Evidências da tentativa estão em evidence-v4/source-access.json.

---

## Registro anterior v3

# Fontes e decisões — 28/10/2026

## Escopo atual

A skill `estiva-wordpress` e suas três referências foram lidas no pacote disponível nesta sessão. O pedido atual prevalece sobre o exemplo Free da skill: site institucional, cardápio Deck e integração efetiva com Elementor Pro. A versão anterior PUB/Club foi preservada em `previous/v2` e em backup fora do checkout; seu escopo não foi transportado para esta nova implementação.

## Site e referências web

As requisições HTTPS a `https://estivacervejaria.com.br/`, `https://www.instagram.com/estivacervejaria/` e `https://brewery.nicdark.com/?storefront=envato-elements` foram bloqueadas pelo proxy com **403**. Isso não estabelece que os sites estejam fora do ar. Não foi possível auditar conteúdo ao vivo, fotografias, contatos ou preços atuais. A evidência da tentativa está em `evidence/source-access.json`.

Portanto, a referência editorial/visual efetivamente usada foi o material da skill: identidade carvão/preto + amarelo + branco, liberdade de escolha, cerveja artesanal em Santos e estética industrial/portuária. Nenhum código, CSS, fonte ou imagem do template Nicdark foi copiado. Esta entrega não é apresentada como uma auditoria ou reprodução do site atual.

## Anexos

O folheto institucional apresenta seis estilos: Pilsner, American IPA, Hop Lager, Premium Lager, Chopp Black e Wine Beer. Não foram inventados ABV, IBU, preços dessas cervejas ou alegação atual de ausência de glúten. Autosserviço com cadastro, cartão pré-pago, torneiras e uso nas filiais aparece apenas como referência histórica sujeita a confirmação. O mesmo cuidado é aplicado a chopeiras, Bikebeer e Kombeer.

O PDF é exclusivo do **Deck**, sem ano/vigência confirmados. A transcrição estruturada preserva 23 itens em seis categorias, descrições, preços e porções disponíveis. R$15 dos espetinhos fica agrupado com os sabores e a ambiguidade indicada; growler 1L permanece sem preço. Não se presume equivalência comercial entre Brewpub/Fábrica/Deck/Beach Bar, nem se transfere preço entre unidades.

Os dados permanecem em `inc/menu-data.json`, sem preços fixos nos templates. Testes confrontam todos os campos de origem e exercitam a exclusão de itens de outras unidades.

## Elementor Pro fornecido pelo usuário

O usuário informou que o Pro estava em uma instalação local e enviou `elementor-pro.zip`. O pacote informa versão **4.3.0**, WordPress mínimo **6.8**, Core mínimo **4.0** e recomendado **4.3**. Foi usado com Core **4.3.4**, WordPress **7.1.3** e PHP **8.3.35**. O ZIP passou no CRC e na inspeção de caminhos antes da instalação.

SHA-256 do arquivo recebido: `f7c9b9a9708f38f455c76d19d7f72db1f2b32590a887f6682c21bc4cb3f7f0f7`. Esse hash identifica o arquivo recebido; não é uma certificação de assinatura do fornecedor. Não foram modificados arquivos do plugin, mecanismos de licença ou verificações TLS. A licença/ativação de conta não é redistribuída ou afirmada como validada. O binário Pro não está nos ZIPs de entrega.

## Implementação autoral e fontes tipográficas

Paleta inicial `#F3C316` / `#111111`: aproximação configurável, não hex oficial. Logo oficial e fotos podem ser substituídos no painel; a marca textual de fallback não é um arquivo de logo inventado. Copos e painéis foram desenhados em CSS; não são fotografias dos produtos/unidades. O screenshot é do site implementado.

Barlow Regular e Barlow Condensed Bold foram obtidas pelo repositório público Google Fonts, com licenças SIL OFL preservadas em `assets/fonts/`. URLs de origem:

- `https://raw.githubusercontent.com/google/fonts/main/ofl/barlow/Barlow-Regular.ttf`
- `https://raw.githubusercontent.com/google/fonts/main/ofl/barlowcondensed/BarlowCondensed-Bold.ttf`

Os downloads usaram HTTPS verificado. As fontes são locais e foram registradas no Elementor; não há CDN obrigatório no tema. Serviços opcionais do plugin/kit devem ser configurados conforme a política de privacidade da instalação.

## Revisão comercial pendente

Confirmar logo, mídias licenciadas, endereços, horários, contatos, disponibilidade, preços, alergênicos, serviços atuais, operação do cartão e texto de privacidade. Os campos desconhecidos ficam vazios, e o impresso é identificado como referência. Nenhuma alteração foi feita no site em produção ou na instalação local do usuário; testes ocorreram no QA isolado deste ambiente.
