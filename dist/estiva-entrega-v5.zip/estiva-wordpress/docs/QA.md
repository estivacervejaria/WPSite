# QA — Estiva Cervejaria v5

Execução em 11/11/2026, em WordPress descartável local. WordPress 7.1.3, PHP 8.3.35, MariaDB 11.4.13, Elementor 4.3.4 e Pro 4.3.0 fornecido pelo usuário. Nenhum servidor de produção, DNS ou banco do usuário foi alterado.

## Verificações desta execução

| Verificação | Resultado |
|---|---|
| Fotos, páginas, metadados, HTTP de derivados e reprodução do vídeo | 264 verificações aprovadas |
| Manutenção pelo painel, acesso anônimo, acesso administrativo, REST e desligamento | 69 verificações aprovadas |
| Regressão com Elementor Pro | 107 verificações aprovadas |
| Regressão com Elementor gratuito | 98 verificações aprovadas |
| Regressão sem Elementor, ZIP instalado em instância limpa | 98 verificações aprovadas |
| Upload real do ZIP, páginas automáticas e importação opcional | 13 verificações aprovadas |
| Catálogo, fonte de dados, segurança de campos e APIs Pro | 129 verificações runtime aprovadas |
| Formulário de contato e preservação de páginas | 25 verificações runtime aprovadas |
| Acervo, importação, edição de alt/galeria e permissões de manutenção | 14 verificações runtime aprovadas |
| Editor Elementor gratuito | Início e Cardápio Deck editados, publicados e restaurados pelo editor real |
| axe-core 4.11.0, nove rotas, 360 e 1440 px | 18 varreduras sem violações detectadas |
| PHP e estrutura do tema | 21 arquivos PHP sintaticamente válidos; arquivos obrigatórios presentes |

A validação visual e de layout incluiu 360/768/1280/1440 px. Todas as imagens verificadas foram decodificadas pelo navegador e têm alt; src/srcset apontam a arquivos locais com HTTP 200. Os WebP foram abertos e verificados quanto a dimensões e ausência de EXIF. O MP4 foi decodificado pelo Chromium e conferido por ffprobe: H.264, sem áudio, metadados de localização ausentes e faststart.

Praiamar está ausente da lista ativa de duas unidades e identificado na galeria histórica com encerramento no início de 2026. Brewpub e Fábrica aparecem juntos na Ana Costa, com galerias distintas; o quiosque permanece no Canal 3. Os eventos são registros, sem agenda inventada.

O importador de acervo criou 24 anexos (22 fotos, pôster e vídeo); repetição criou zero. Alt e seleção de galeria foram alterados temporariamente e restaurados. As permissões de editor e assinante foram verificadas com usuários temporários, removidos após o teste. A biblioteca de QA mantém o acervo importado.

## Manutenção

O teste ativou o modo no painel administrativo e confirmou HTTP 503, HTML correto, Retry-After, noindex e não cache em início, unidades, contato, sobre, página de manutenção, busca, feed e sitemap. O acesso anônimo à API REST foi bloqueado com503. Login e CSS permaneceram acessíveis; o administrador viu o site completo e o indicador de manutenção. As capacidades de editor/assinante foram verificadas no runtime. O desligamento restaurou páginas públicas e REST. A página independente de prévia mantém HTTP200 e noindex. A configuração original foi restaurada no finally: o modo não ficou ligado no QA.

Foi corrigido um problema de Content-Type do feed: o WordPress enviava RSS para o documento de manutenção. A resposta de manutenção agora define explicitamente HTML. Também foram excluídos os scripts frontend do Elementor apenas no documento de manutenção, evitando carregamento sem a configuração de um documento Elementor. As páginas normais mantêm seus scripts.

Manutenção não é controle de privacidade de arquivos estáticos, firewall ou substituto da proteção do servidor. Cache externo pode servir conteúdo anterior até ser purgado; a ativação exige essa revisão no servidor de destino.

## Artefatos e reprodução

Evidências atuais em **evidence-v5/**. O pacote completo inclui JSONs/logs e capturas representativas em 360/1440 px, além de capturas do editor. Capturas redundantes dos perfis e das larguras intermediárias permanecem no workspace. Evidências antigas continuam preservadas fora do pacote v5; não são contadas como nova execução.

- `bash scripts/dev-up.sh`: QA principal com pacote Pro legítimo fora do checkout.
- `python scripts/media-v5-tests.py`: imagens, galerias, vídeo e layout; execute com manutenção desligada.
- `python scripts/maintenance-v5-tests.py`: login, ativação e desligamento reais no painel; execute isoladamente das suítes frontend. O script restaura a opção anterior em finally.
- `media-runtime-v5.php`, `runtime-tests.php`, `contact-tests.php`: executar via WP-CLI como administrador no QA. O teste de contato intercepta wp_mail, sem envio externo.
- `scripts/browser-tests.py`: aceita ESTIVA_PROFILE, ESTIVA_TEST_URL e ESTIVA_EVIDENCE_DIR.
- `python scripts/free-editor-v5-tests.py`: executar com Elementor Core ativo e Pro desativado no QA; restaura as edições temporárias.
- `python scripts/accessibility-v5-tests.py`: Chromium e axe-core local, verifica HTTP e presença do main antes de executar axe.
- Instalação limpa: `ESTIVA_ZIP_CONTAINER=estiva-v5-zip ESTIVA_ZIP_PORT=8083 ESTIVA_ZIP_PREFIX=zip_v5_ python scripts/zip-install-env.py`, configure upload_max_filesize32M/post_max_size40M no PHP da instância descartável e reinicie-a; em seguida execute `python scripts/upload-v5-tests.py`. Exige tabelas/contêiner ainda inexistentes.
- `python scripts/package.py` e `python scripts/package-complete.py`: empacotamento. O ZIP final foi reinstalado e cada arquivo comparado com o fonte e com o ZIP em installed-zip-verification.json.

## Limitações

Estiva_Copa.MP4 e Praiamar 5.MP4 não foram baixados, convertidos ou testados: excedem 32 MiB. Não se alega que foram incluídos. As 22 fotos HEIC e o MOV curto foram processados; imagens inline sem arquivo local não foram extraídas/recriadas. A história detalhada de fundação e os marcos não foram fornecidos. O acesso ao site público, Instagram e referência externa continua bloqueado pelo proxy com403. As novas fontes são os anexos e as confirmações do usuário.

Não houve teste de entrega de e-mail real, configuração SMTP, Safari, leitor de tela humano, migração de produção, licença/serviços comerciais do Pro ou modelo próprio de archive Pro. Há verificações axe inconclusivas para revisão humana; não é certificação de acessibilidade. Os testes de contato não dispararam e-mails externos. Os serviços WordPress.org continuam gerando avisos de rede; TLS/assinaturas não foram desativados. Os testes iniciais de manutenção detectaram erros de script e Content-Type, corrigidos e novamente verificados; não são contabilizados como aprovações.

O ZIP do tema não contém credenciais, banco, plugin pago, licença ou fixture ativa de e-mail. A identidade usa as fontes OFL e o esquema preto/amarelo do projeto, sem fabricar um logotipo original.
