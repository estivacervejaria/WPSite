# Estiva Cervejaria — v5

Tema WordPress instalável com acervo real e modo de manutenção.

**Aparência → Manutenção Estiva** ativa a apresentação para visitantes, com contatos, identidade visual, foto do quiosque e HTTP 503. Administradores/editores podem continuar trabalhando; a API REST pública fica bloqueada. O modo vem desativado. Limpe caches após mudar a opção.

As nove páginas ausentes são criadas no primeiro acesso administrativo, sem sobrescrever páginas existentes. O tema integra Elementor/Pro legítimo, cardápio Deck e fallback sem plugins. Pro/licença não são redistribuídos.

Inclui 22 fotos em WebP e um vídeo curto de ambiente sem áudio, com controles e sem autoplay. Unidades atuais: Brewpub e Fábrica juntos na Ana Costa; quiosque no Canal 3. Praiamar é memória de unidade encerrada no início de 2026, com galeria histórica em Sobre. Há galeria de eventos sem agenda fictícia. Acervo importável na biblioteca, galerias e destaques editáveis.

Dois vídeos maiores que 32 MiB permanecem pendentes por limite da ferramenta de transferência. A história detalhada ainda depende de texto aprovado. O site público segue inacessível neste ambiente por HTTP 403.

`theme/estiva-cervejaria` contém o código; `dist/estiva-cervejaria.zip` é o tema instalável (aproximadamente 13 MB). `docs/INSTALL.md` explica atualização, manutenção, mídia e migração. `docs/QA.md` registra os testes atuais em `docs/evidence-v5/`. Evidências antigas e versões previous/ são preservadas no workspace, fora do pacote v5. Credenciais, bancos, plugins pagos e originais HEIC não integram a distribuição.
