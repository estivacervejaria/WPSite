from pathlib import Path
import json,subprocess
from PIL import Image
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];OUT=R/'docs/evidence-v5';OUT.mkdir(exist_ok=True);BASE='http://localhost:8080';checks=[]
def check(name,ok):
 checks.append({'test':name,'passed':bool(ok)});assert ok,name
catalog=json.loads((R/'theme/estiva-cervejaria/assets/media/catalog.json').read_text())
check('22 photos and one ambient video',sum('video' not in e for e in catalog)==22 and sum('video' in e for e in catalog)==1)
for e in catalog:
 for v in e['variants']:
  p=R/'theme/estiva-cervejaria/assets/media'/v['file']
  with Image.open(p) as im:check(v['file']+' valid dimensions and no EXIF',im.size==(v['width'],v['height']) and not im.getexif())
 if 'video' in e:
  p=R/'theme/estiva-cervejaria/assets/media'/e['video'];probe=json.loads(subprocess.check_output(['ffprobe','-v','quiet','-show_streams','-show_format','-of','json',str(p)],text=True));check('H264 video without audio',len(probe['streams'])==1 and probe['streams'][0]['codec_name']=='h264');data=p.read_bytes();check('faststart video',data.find(b'moov')<data.find(b'mdat'));check('video GPS removed',not any('location' in k.lower() for k in probe['format'].get('tags',{})))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 for width in [360,768,1280,1440]:
  page.set_viewport_size({'width':width,'height':1000})
  for slug in ['', 'unidades','sobre','eventos','manutencao']:
   res=page.goto(BASE+'/'+slug+('/' if slug else ''));page.wait_for_load_state('networkidle');check(f'{slug or "home"} HTTP200 {width}',res.status==200);check(f'{slug} single H1 {width}',page.locator('h1').count()==1);check(f'{slug} no overflow {width}',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   # Force lazy images into view before checking actual decoding.
   for image in page.locator('main img').all():image.scroll_into_view_if_needed();image.evaluate('(img)=>img.loading="eager"');image.evaluate('(img)=>img.decode()')
   check(f'{slug} real images decoded {width}',page.locator('main img').count()>0 and page.locator('main img').evaluate_all('(imgs)=>imgs.every(i=>i.complete&&i.naturalWidth>0&&i.alt.length>0)'))
   if slug=='unidades':
    check(f'2 current venues {width}',page.locator('.unit-with-photo').count()==2);check(f'Brewpub and factory together {width}','Brewpub e Fábrica' in page.locator('.unit-with-photo').first.inner_text());check(f'Praiamar excluded from active venues {width}','Praiamar' not in page.locator('main').inner_text());check(f'3 venue galleries {width}',page.locator('[data-gallery]').count()==3);check(f'video manual controls {width}',page.locator('video').count()==1 and page.locator('video').get_attribute('controls') is not None and page.locator('video').get_attribute('autoplay') is None)
   if slug=='sobre':check(f'closed Praiamar identified {width}','encerrada no início de 2026' in page.locator('.estiva-memory').inner_text());check(f'6 historical photos {width}',page.locator('[data-gallery=historia] figure').count()==6)
   if slug=='eventos':check(f'5 event photos {width}',page.locator('[data-gallery=eventos] figure').count()==5)
   if slug=='manutencao':check(f'maintenance contacts {width}',page.locator('a[href="mailto:faleconosco@estivacervejaria.com.br"]').count()==2 and page.locator('a[href="https://www.instagram.com/estivacervejaria/"]').count()==1);check(f'maintenance no site nav {width}',page.locator('#estiva-navigation').count()==0)
   page.evaluate('scrollTo(0,0)');page.screenshot(path=str(OUT/f'{slug or "home"}-{width}.png'),full_page=True)
 page.goto(BASE+'/unidades/');video=page.locator('video');video.scroll_into_view_if_needed();video.evaluate('(v)=>v.load()');page.wait_for_function('document.querySelector("video").readyState>=1');check('video actually decodes',video.evaluate('(v)=>v.videoWidth>0&&v.duration>0'))
 for e in catalog:
  for v in e['variants']:check(v['file']+' HTTP200',page.request.get(BASE+'/wp-content/themes/estiva-cervejaria/assets/media/'+v['file']).status==200)
 check('no JS errors',not errors);b.close()
(OUT/'media-browser-results.json').write_text(json.dumps(checks,indent=2));print(len(checks),'media checks passed')
