"""Package current sources and evidence; exclude private runtimes and prior versions."""
from pathlib import Path
import zipfile
R=Path(__file__).resolve().parents[1]
files=[]
for name in ('theme','docs','scripts','skills'):
 files.extend(p for p in (R/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and not (name=='docs' and p.suffix=='.png' and (p.parent.name in ('pro','free','zip-native') or (not p.stem.endswith(('360','1440')) and not p.stem.startswith('free-editor-')))) and not (name=='docs' and any(x in ('evidence','evidence-v4') for x in p.relative_to(R/name).parts)))
files.extend(R/n for n in ('README.md','AGENTS.md','.gitignore','dist/estiva-cervejaria.zip','dist/SHA256SUMS'))
out=R/'dist/estiva-entrega-v5.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):
  assert not p.is_symlink()
  relative=p.relative_to(R)
  assert p.name not in ('runtime.env','elementor-pro.zip','wp-config.php')
  z.write(p,Path('estiva-wordpress')/relative)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
print(out)
