<?php
function media_check($name,$ok) { if (!$ok) { throw new RuntimeException($name); }echo "PASS: $name\n"; }
media_check('gallery sanitization',estiva_gallery_ids('1,2,bad,1,-5')==='1,2,5');
media_check('gallery rejects arrays',estiva_gallery_ids(['bad'])==='');
media_check('unknown gallery rejected',estiva_gallery_markup('unknown')==='');
media_check('unknown photo rejected',estiva_media_image('unknown')==='');
media_check('22 photos and 1 video',count(estiva_media_catalog())===23);
media_check('9 pages including maintenance',count(estiva_pages())===9 && isset(estiva_pages()['manutencao']));
media_check('Praiamar never active unit',strpos(wp_json_encode(estiva_public_units()),'Praiamar')===false);
$expected=0;foreach (estiva_media_catalog() as $entry) { if (!estiva_media_attachment($entry['key'])) { $expected++; }if (isset($entry['video']) && !estiva_media_attachment($entry['key'].':video')) { $expected++; } }$before=estiva_import_media();media_check('import creates all missing optimized assets',$before===$expected);media_check('repeat import creates zero',estiva_import_media()===0);
$attachment=estiva_media_attachment('fabrica-1');media_check('imported source-key retrievable',$attachment>0 && wp_attachment_is_image($attachment));
$old=get_post_meta($attachment,'_wp_attachment_image_alt',true);update_post_meta($attachment,'_wp_attachment_image_alt','Texto alternativo editado no painel');media_check('library alt remains editable',strpos(estiva_media_image('fabrica-1'),'Texto alternativo editado no painel')!==false);update_post_meta($attachment,'_wp_attachment_image_alt',$old);
$old_gallery=get_theme_mod('estiva_gallery_fabrica',null);set_theme_mod('estiva_gallery_fabrica',(string)$attachment);media_check('gallery can use library selection',substr_count(estiva_gallery_markup('fabrica'),'<figure')===1);if ($old_gallery===null) { remove_theme_mod('estiva_gallery_fabrica'); }else { set_theme_mod('estiva_gallery_fabrica',$old_gallery); }
$original_user=get_current_user_id();$test_users=[];
try {
 foreach (['editor'=>true,'subscriber'=>false] as $role=>$expected) {
  $id=wp_insert_user(['user_login'=>'estiva-v5-'.wp_generate_uuid4(),'user_pass'=>wp_generate_password(30,true),'role'=>$role]);if (is_wp_error($id)) { throw new RuntimeException('Cannot create role fixture'); }$test_users[]=$id;wp_set_current_user($id);media_check($role.' maintenance permission',estiva_maintenance_bypass()===$expected);
 }
} finally { wp_set_current_user($original_user);require_once ABSPATH.'wp-admin/includes/user.php';foreach ($test_users as $id) { wp_delete_user($id); } }
echo "Media import stays in QA; role fixtures removed.\n";
