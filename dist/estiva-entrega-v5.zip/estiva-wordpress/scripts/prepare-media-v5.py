"""Technical HEIC/WebP and ambient-video conversion; originals stay outside the repo."""
from pathlib import Path
from PIL import Image
import json,subprocess,hashlib
R=Path(__file__).resolve().parents[1];PRIVATE=Path('/workspace/estiva-v5-media');OUT=R/'theme/estiva-cervejaria/assets/media';OUT.mkdir(exist_ok=True)
catalog=json.loads((PRIVATE/'catalog.json').read_text());result=[]
labels={
'evento1':('eventos','Estrutura de atendimento Estiva em um evento'),
'evento':('eventos','Atendimento da Estiva com guarda-sóis em um evento noturno'),
'evento2':('eventos','Kombeer amarela e equipe em um evento ao ar livre'),
'evento-8':('eventos','Presença da Estiva em um evento na cidade'),
'evento-10':('eventos','Estrutura Estiva com guarda-sol em um evento'),
'brewpub':('brewpub','Público reunido no Brewpub Estiva na Avenida Ana Costa'),
'brewpub2':('brewpub','Ambiente do Brewpub com parede de torneiras e arte Estiva'),
'brewpub4':('brewpub','Torneiras do Brewpub na parede de tijolos com arte Estiva'),
'brewpub5':('brewpub','Parede de autosserviço do Brewpub Estiva'),
'brewpub-halloween':('brewpub','Registro temático de Halloween no Brewpub Estiva'),
'fabrica-1':('fabrica','Detalhe de equipamento da fábrica da Estiva'),
'fabrica-2':('fabrica','Tanques de inox na fábrica da Estiva junto ao Brewpub'),
'quiosque-por-do-sol':('quiosque','Pôr do sol na praia junto ao quiosque Estiva'),
'quiosque-2':('quiosque','Ambiente ao ar livre junto ao quiosque Estiva no Canal 3'),
'quiosque-7':('quiosque','Vista da praia a partir do quiosque Estiva'),
'quiosque-5':('quiosque','Torneiras e copo de cerveja no quiosque Estiva'),
'quiosque-3':('quiosque','Balcão e ambiente do quiosque Estiva, em vídeo sem áudio'),
'praiamar':('historia','Antiga loja Estiva no Shopping Praiamar — unidade encerrada'),
'praiamar-1':('historia','Parede de torneiras da antiga loja Praiamar — unidade encerrada'),
'praiamar-3':('historia','Fachada e ambiente da antiga loja Praiamar — unidade encerrada'),
'praiamar-parede-1':('historia','Arte na parede da antiga loja Praiamar — unidade encerrada'),
'praiamar-parede-2':('historia','Mural colorido da antiga loja Praiamar — unidade encerrada'),
'praiamar-parede-3':('historia','Detalhe do mural da antiga loja Praiamar — unidade encerrada')}
for f in catalog:
 key=f['key'];group,alt=labels[key];preview=PRIVATE/'previews'/(key+'.jpg');entry={'key':key,'group':group,'alt':alt,'source_name':f['name'],'source_sha256':f['sha256'],'variants':[]}
 with Image.open(preview) as im:
  im=im.convert('RGB');entry['original_dimensions']=list(im.size)
  for width in [480,960,1600]:
   image=im.copy();image.thumbnail((width,width*10),Image.Resampling.LANCZOS);name=f'{key}-{width}.webp';image.save(OUT/name,'WEBP',quality=80,method=6,exif=b'');entry['variants'].append({'file':name,'width':image.width,'height':image.height,'bytes':(OUT/name).stat().st_size})
 if 'probe' in f:
  name=key+'.mp4';subprocess.run(['ffmpeg','-v','error','-y','-i',f['path'],'-map','0:v:0','-vf',"scale='min(960,iw)':-2",'-c:v','libx264','-preset','medium','-crf','26','-pix_fmt','yuv420p','-an','-map_metadata','-1','-movflags','+faststart',str(OUT/name)],check=True);entry['video']=name;entry['duration']=float(f['probe']['format']['duration'])
 result.append(entry)
(OUT/'catalog.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('Prepared',len(result),'media entries;',sum(p.stat().st_size for p in OUT.iterdir()),'bytes')
