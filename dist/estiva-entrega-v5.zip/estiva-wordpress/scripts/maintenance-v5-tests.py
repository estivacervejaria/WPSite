from pathlib import Path
import json,subprocess
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];OUT=R/'docs/evidence-v5';BASE='http://localhost:8080';V=dict(x.split('=',1) for x in Path('/workspace/estiva-v3-runtime/runtime.env').read_text().splitlines());checks=[]
def check(label,ok):
 checks.append({'test':label,'passed':bool(ok)});assert ok,label
def wp(args):return subprocess.check_output(['docker','exec','estiva-v3-wordpress-1','php','/usr/local/bin/wp','--allow-root']+args,text=True)
old=wp(['option','get','estiva_maintenance_enabled','--format=json']) if wp(['eval','echo get_option("estiva_maintenance_enabled","missing");'])!='missing' else None
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);admin=b.new_context();page=admin.new_page();page.set_default_timeout(90000);page.set_default_navigation_timeout(90000);page.goto(BASE+'/wp-login.php');page.locator('#user_login').fill('estiva_qa');page.locator('#user_pass').fill(V['ADMIN_PASSWORD']);page.locator('#wp-submit').click();page.wait_for_url('**/wp-admin/**',wait_until='domcontentloaded');page.goto(BASE+'/wp-admin/themes.php?page=estiva-maintenance');page.locator('[name=maintenance_enabled]').check();page.get_by_role('button',name='Salvar manutenção').click();check('admin UI enabled mode','Configuração de manutenção salva' in page.locator('body').inner_text());check('admin still accesses full site',page.goto(BASE+'/unidades/').status==200 and page.locator('.unit-with-photo').count()==2);check('admin status indicator',page.locator('#wp-admin-bar-estiva-maintenance').count()==1)
  anonymous=b.new_context(viewport={'width':360,'height':900});visitor=anonymous.new_page()
  for route in ['/','/unidades/','/contato/','/sobre/','/manutencao/','/feed/','/?s=cerveja','/wp-sitemap.xml']:
   res=visitor.goto(BASE+route);check(route+' public503',res.status==503);check(route+' HTML document','text/html' in res.headers.get('content-type',''));check(route+' retry-after',res.headers.get('retry-after')=='3600');check(route+' no-cache','no-cache' in res.headers.get('cache-control',''));check(route+' noindex','noindex' in res.headers.get('x-robots-tag',''));check(route+' contact and brand','faleconosco@estivacervejaria.com.br' in visitor.locator('main').inner_text() and 'ESTIVA' in visitor.locator('main').inner_text());check(route+' no nav leak',visitor.locator('#estiva-navigation').count()==0)
  for width in [360,768,1280,1440]:
   visitor.set_viewport_size({'width':width,'height':1000});visitor.goto(BASE+'/');check(f'maintenance fits{width}',visitor.evaluate('document.documentElement.scrollWidth<=innerWidth'));visitor.screenshot(path=str(OUT/f'maintenance-active-{width}.png'),full_page=True)
  res=anonymous.request.get(BASE+'/wp-json/wp/v2/pages');check('public REST blocked',res.status==503 and res.json().get('code')=='estiva_maintenance');check('login remains available',anonymous.request.get(BASE+'/wp-login.php').status==200);check('CSS remains available',anonymous.request.get(BASE+'/wp-content/themes/estiva-cervejaria/assets/site.css').status==200)
  page.goto(BASE+'/wp-admin/themes.php?page=estiva-maintenance');page.locator('[name=maintenance_enabled]').uncheck();page.get_by_role('button',name='Salvar manutenção').click();res=visitor.goto(BASE+'/');check('disable restores public site',res.status==200 and visitor.locator('.hero').count()==1);check('disable restores REST',anonymous.request.get(BASE+'/wp-json/wp/v2/pages').status==200);res=visitor.goto(BASE+'/manutencao/');check('standalone preview remains200',res.status==200 and 'noindex' in res.headers.get('x-robots-tag',''));b.close()
finally:
 if old is None:wp(['eval','delete_option("estiva_maintenance_enabled");'])
 else:wp(['option','update','estiva_maintenance_enabled',old,'--format=json'])
(OUT/'maintenance-results.json').write_text(json.dumps(checks,indent=2));print(len(checks),'maintenance assertions passed')
