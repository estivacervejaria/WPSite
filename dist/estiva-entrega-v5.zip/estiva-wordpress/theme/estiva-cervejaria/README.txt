Estiva Cervejaria 5.0.0

Instale o ZIP do tema pelo painel WordPress e confirme a substituição da versão anterior. Acesse o painel como administrador para criar somente as páginas ausentes; nove páginas, incluindo Manutenção. O upload precisa comportar aproximadamente 13 MB; 32 MB é suficiente.

Aparência > Manutenção Estiva: ative a manutenção para visitantes. O modo vem desligado. Administradores e editores autenticados continuam acessando o site; visitantes recebem HTTP 503 com contatos. Limpe os caches do servidor/plugins/CDN após mudar a opção. /manutencao/ é a prévia com noindex. Esta função não torna os arquivos estáticos privados.
Contatos: Instagram @estivacervejaria; faleconosco@estivacervejaria.com.br. E-mail público, Instagram e WhatsApp são editados em Personalizar. O formulário normal de Contato usa wp_mail: configure o correio do servidor para entrega real.

Acervo: 22 fotos WebP e um vídeo curto do quiosque em H.264, sem áudio, sem autoplay. Brewpub e Fábrica ficam juntos na Ana Costa; quiosque no Canal 3. Praiamar aparece apenas como memória da unidade encerrada no início de 2026.
Aparência > Acervo Estiva: importe cópias otimizadas na biblioteca, sem duplicação, para escolher imagens nos widgets Elementor. Personalizar > Estiva: imagens principais e IDs das galerias. Os arquivos incluídos funcionam sem importação.
Dois vídeos maiores que 32 MiB permanecem pendentes de transferência. A história detalhada ainda depende de texto aprovado. Originais HEIC não integram o ZIP.

Aparência > Importar conteúdo Estiva: 23 produtos Deck e seis cervejas de referência; preços a revisar.
Aparência > Preparar Elementor: prepara páginas originais, exceto Manutenção e Privacidade. Modelos Pro exigem plugin legítimo já instalado; não há plugin nem licença Pro no ZIP.

Documentação completa e evidências da v5 estão no pacote de fontes, docs/INSTALL.md e docs/QA.md. Versões anteriores não foram removidas do workspace. Fontes Barlow e Barlow Condensed sob SIL OFL; licenças em assets/fonts. As fotos foram fornecidas pelo usuário e convertidas tecnicamente, sem criação de cenas ou logos.
