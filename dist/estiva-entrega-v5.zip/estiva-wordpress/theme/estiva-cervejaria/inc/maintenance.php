<?php
if (!defined('ABSPATH')) { exit; }
function estiva_maintenance_enabled() { return (bool)get_option('estiva_maintenance_enabled',false); }
function estiva_maintenance_bypass() { return current_user_can('edit_pages') || current_user_can('manage_options'); }
function estiva_maintenance_markup() {
 $email=get_theme_mod('estiva_email','') ?: 'faleconosco@estivacervejaria.com.br';$ig=get_theme_mod('estiva_instagram','https://www.instagram.com/estivacervejaria/');$whatsapp=get_theme_mod('estiva_whatsapp','');
 ob_start(); ?><main id="main" class="maintenance-main" tabindex="-1"><div class="maintenance-card"><div class="wordmark maintenance-brand"><?php if (has_custom_logo()) { echo wp_get_attachment_image(get_theme_mod('custom_logo'),'full',false,['class'=>'logo-image','sizes'=>'180px']); } else { ?><span>ESTIVA<small>CERVEJARIA · SANTOS / BRASIL</small></span><?php } ?></div><span class="eyebrow">Um novo encontro está chegando</span><h1><?php echo esc_html(get_option('estiva_maintenance_title',"Estamos preparando\nnosso novo site.")); ?></h1><p class="maintenance-intro"><?php echo esc_html(get_option('estiva_maintenance_text','Estamos renovando nosso site para receber você ainda melhor. Enquanto isso, acompanhe a Estiva nas redes sociais ou fale com a nossa equipe.')); ?></p><div class="maintenance-venues"><p><strong>Brewpub e Fábrica</strong><br>Avenida Ana Costa, Santos</p><p><strong>Quiosque na praia</strong><br>Canal 3, Santos</p></div><div class="actions"><?php if ($ig) { ?><a class="button" href="<?php echo esc_url($ig); ?>">Instagram <span class="arrow" aria-hidden="true"></span></a><?php }if (is_email($email)) { ?><a class="button button-outline" href="<?php echo esc_url('mailto:'.$email); ?>">Enviar e-mail</a><?php }if ($whatsapp) { ?><a class="button button-outline" href="<?php echo esc_url($whatsapp); ?>">WhatsApp</a><?php } ?></div><?php if (is_email($email)) { ?><p class="maintenance-email"><a href="<?php echo esc_url('mailto:'.$email); ?>"><?php echo esc_html($email); ?></a></p><?php } ?><p class="maintenance-responsibility">Beba com responsabilidade. Venda de bebidas alcoólicas proibida a menores de 18 anos.</p></div><div class="maintenance-photo"><?php echo estiva_media_image('quiosque-por-do-sol',['loading'=>'eager','fetchpriority'=>'high','sizes'=>'(max-width:900px)100vw,40vw']); ?><span>Estiva onde estiver.</span></div></main><?php return ob_get_clean();
}
function estiva_maintenance_document($temporary=false) {
 header('Content-Type: text/html; charset='.get_bloginfo('charset'),true);
 if ($temporary) { status_header(503);header('Retry-After: 3600'); }
 if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE',true); }nocache_headers();header('X-Robots-Tag: noindex, nofollow',true);
 ?><!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><?php wp_head(); ?></head><body <?php body_class('estiva-maintenance'); ?>><?php wp_body_open(); ?><a class="skip-link" href="#main">Pular para o conteúdo</a><?php echo estiva_maintenance_markup();wp_footer(); ?></body></html><?php
}
add_shortcode('estiva_maintenance','estiva_maintenance_markup');
add_action('template_redirect',function () {
 if (estiva_maintenance_enabled() && !estiva_maintenance_bypass()) { estiva_maintenance_document(true);exit; }
 if (is_page('manutencao')) { estiva_maintenance_document(false);exit; }
},-100);
add_filter('rest_pre_dispatch',function ($result) {
 if (estiva_maintenance_enabled() && !estiva_maintenance_bypass()) { return new WP_Error('estiva_maintenance','Site temporariamente em manutenção. Fale com a Estiva pelo Instagram ou e-mail.',['status'=>503]); }return $result;
},-100);
add_filter('wp_sitemaps_enabled',function ($enabled) { return estiva_maintenance_enabled()?false:$enabled; });
add_action('admin_menu',function () { add_theme_page('Manutenção Estiva','Manutenção Estiva','manage_options','estiva-maintenance',function () {
 if (!current_user_can('manage_options')) { return; }
 if (isset($_POST['estiva_maintenance_save'])) {
  check_admin_referer('estiva_maintenance_save');update_option('estiva_maintenance_enabled',!empty($_POST['maintenance_enabled']));
  foreach (['title','text'] as $field) { $value=$_POST['maintenance_'.$field]??'';if (is_string($value)) { $value=sanitize_textarea_field(wp_unslash($value));if (trim($value)==='') { delete_option('estiva_maintenance_'.$field); } else { update_option('estiva_maintenance_'.$field,$value); } } }
  echo '<div class="notice notice-success"><p>Configuração de manutenção salva.</p></div>';
 }
 echo '<div class="wrap"><h1>Manutenção Estiva</h1><p>Quando ativada, visitantes recebem uma página de manutenção com status HTTP 503. Administradores e editores autenticados podem navegar no site. O painel e o login continuam disponíveis. O modo vem desativado.</p><p>Depois de ativar ou desativar, limpe o cache do servidor, do plugin de cache e da CDN. Caso contrário, páginas antigas podem continuar aparecendo.</p><form method="post">';wp_nonce_field('estiva_maintenance_save');
 echo '<p><label><input type="checkbox" name="maintenance_enabled" value="1" '.checked(estiva_maintenance_enabled(),true,false).'> Ativar manutenção para visitantes</label></p><p><label>Título<br><textarea name="maintenance_title" rows="2" cols="60">'.esc_textarea(get_option('estiva_maintenance_title',"Estamos preparando\nnosso novo site.")).'</textarea></label></p><p><label>Mensagem<br><textarea name="maintenance_text" rows="4" cols="60">'.esc_textarea(get_option('estiva_maintenance_text','Estamos renovando nosso site para receber você ainda melhor. Enquanto isso, acompanhe a Estiva nas redes sociais ou fale com a nossa equipe.')).'</textarea></label></p><p>Instagram, e-mail público e WhatsApp são editados em Aparência → Personalizar → Estiva — identidade e conteúdo.</p><button class="button button-primary" name="estiva_maintenance_save" value="1">Salvar manutenção</button></form><p><a href="'.esc_url(estiva_link('manutencao')).'" target="_blank" rel="noopener">Visualizar página de manutenção</a></p></div>';
 }); });
add_action('admin_bar_menu',function ($bar) { if (estiva_maintenance_enabled() && estiva_maintenance_bypass()) { $bar->add_node(['id'=>'estiva-maintenance','title'=>'Estiva: manutenção ATIVA','href'=>admin_url('themes.php?page=estiva-maintenance')]); } },100);

add_filter('document_title_parts',function ($parts) { if (is_page('manutencao') || (estiva_maintenance_enabled() && !estiva_maintenance_bypass())) { $parts['title']='Estiva Cervejaria — Em manutenção'; }return $parts; });
// The standalone document contains no Elementor widgets. Do not load its frontend
// runtime without a built document/config; keep plugin assets on the working site.
function estiva_maintenance_scripts() {
 if (!is_page('manutencao') && !(estiva_maintenance_enabled() && !estiva_maintenance_bypass())) { return; }
 foreach (['elementor-frontend','elementor-frontend-modules','elementor-webpack-runtime','elementor-pro-frontend','elementor-pro-webpack-runtime'] as $handle) { wp_dequeue_script($handle); }
}
add_action('wp_enqueue_scripts','estiva_maintenance_scripts',9999);
add_action('wp_print_footer_scripts','estiva_maintenance_scripts',0);
