<?php
if (!defined('ABSPATH')) { exit; }
function estiva_pages() { return ['manutencao'=>['Manutenção','[estiva_maintenance]'],'inicio'=>['Início','[estiva_home]'],'cervejas'=>['Cervejas','[estiva_beers]'],'cardapio-deck'=>['Cardápio Deck','[estiva_menu]'],'unidades'=>['Unidades','[estiva_units]'],'eventos'=>['Eventos','[estiva_events]'],'sobre'=>['Sobre','[estiva_story]'],'contato'=>['Contato','[estiva_contact]'],'politica-de-privacidade'=>['Política de Privacidade','<p>Modelo a revisar pelo responsável antes da publicação. Informe controlador, dados tratados, finalidades, bases legais, retenção, compartilhamento e canal para exercício dos direitos. Serviços externos têm políticas próprias. Este modelo não constitui aconselhamento jurídico.</p><h2>Mensagens pelo formulário</h2><p>O formulário solicita nome, e-mail, assunto e mensagem para que a equipe possa analisar e responder ao contato. Não há inscrição automática em marketing. Os dados são encaminhados ao e-mail faleconosco@estivacervejaria.com.br pelo serviço de correio configurado no servidor. O tema não mantém um arquivo de mensagens no banco do WordPress; registros do provedor de correio ou de plugins adicionais devem ser considerados pelo responsável.</p><p>O formulário usa um identificador técnico com hash e um contador temporário para limitar envios abusivos. O responsável deve definir e informar os prazos de retenção das mensagens e dos registros do servidor antes da publicação. Para dúvidas sobre dados pessoais, contate faleconosco@estivacervejaria.com.br.</p>']]; }
function estiva_create_pages() {
 $n=0;foreach (estiva_pages() as $slug=>$data) { if (!get_page_by_path($slug)) { $id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$data[0],'post_content'=>$data[1]],true);if (is_wp_error($id)) { return $id; }$n++; } }
 if (!get_option('page_on_front')) { update_option('show_on_front','page');update_option('page_on_front',get_page_by_path('inicio')->ID); }
 return $n;
}
function estiva_seed() {
 $n=estiva_create_pages();if (is_wp_error($n)) { return $n; }
 foreach (json_decode(file_get_contents(__DIR__.'/menu-data.json'),true) as $i=>$item) {
  $key='deck:'.sanitize_title($item['title']);if (get_posts(['post_type'=>'estiva_menu_item','post_status'=>'any','meta_key'=>'_estiva_source_key','meta_value'=>$key,'numberposts'=>1])) { continue; }
  $id=wp_insert_post(['post_type'=>'estiva_menu_item','post_status'=>'publish','post_title'=>$item['title'],'post_content'=>$item['description']],true);if (is_wp_error($id)) { return $id; }
  foreach (['price','description','portion','unit'] as $field) { update_post_meta($id,'_estiva_'.$field,$item[$field]); }
  foreach (['source_key'=>$key,'order'=>$i,'available'=>'1','featured'=>'0'] as $f=>$v) { update_post_meta($id,'_estiva_'.$f,$v); }wp_set_object_terms($id,$item['category'],'estiva_menu_category');$n++;
 }
 foreach (['Pilsner','American IPA','Hop Lager','Premium Lager','Chopp Black','Wine Beer'] as $name) { if (!get_page_by_path(sanitize_title($name),OBJECT,'estiva_beer')) { $id=wp_insert_post(['post_type'=>'estiva_beer','post_status'=>'publish','post_name'=>sanitize_title($name),'post_title'=>$name,'post_content'=>'Estilo presente no material institucional. Consulte a unidade sobre características e disponibilidade atuais.'],true);if (is_wp_error($id)) { return $id; }$n++; } }
 flush_rewrite_rules();return $n;
}
add_action('admin_menu',function () { add_theme_page('Conteúdo Estiva','Importar conteúdo Estiva','manage_options','estiva-import',function () {
 if (!current_user_can('manage_options')) { return; }echo '<div class="wrap"><h1>Conteúdo inicial Estiva</h1><p>Adiciona nove páginas, seis cervejas e 23 itens exclusivamente no Deck. Preserva conteúdos existentes. As páginas ausentes são criadas automaticamente no primeiro acesso administrativo. Este botão também importa as cervejas e o cardápio de referência.</p>';
 if (isset($_POST['estiva_import'])) { check_admin_referer('estiva_import');$n=estiva_seed();echo '<p>'.esc_html(is_wp_error($n)?$n->get_error_message():$n.' conteúdos criados.').'</p>'; }echo '<form method="post">';wp_nonce_field('estiva_import');echo '<button class="button button-primary" name="estiva_import" value="1">Importar conteúdo</button></form></div>';
 }); });
if (defined('WP_CLI') && WP_CLI) { WP_CLI::add_command('estiva seed',function () { $n=estiva_seed();if (is_wp_error($n)) { WP_CLI::error($n->get_error_message()); }WP_CLI::success($n.' conteúdos criados.'); }); }

// Only create missing pages. Never replace existing page bodies or front-page choices.
add_action('admin_init',function () {
 if (!current_user_can('manage_options') || get_option('estiva_pages_version')==='5') { return; }
 $result=estiva_create_pages();if (!is_wp_error($result)) { update_option('estiva_pages_version','5');update_option('estiva_pages_setup_created',$result);flush_rewrite_rules(); }
});
add_action('admin_notices',function () {
 if (!current_user_can('manage_options')) { return; }
 $count=(int)get_option('estiva_pages_setup_created');
 if ($count) { echo '<div class="notice notice-success"><p>Estiva: '.esc_html($count).' páginas criadas. <a href="'.esc_url(admin_url('edit.php?post_type=page')).'">Ver páginas</a>. Configure fotos, história e contato em <a href="'.esc_url(admin_url('customize.php')).'">Personalizar</a>. O cardápio pode ser importado em Aparência → Importar conteúdo Estiva.</p></div>';delete_option('estiva_pages_setup_created'); }
});
