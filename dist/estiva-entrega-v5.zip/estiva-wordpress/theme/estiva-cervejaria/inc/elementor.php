<?php
if (!defined('ABSPATH')) { exit; }
add_filter('elementor/fonts/additional_fonts',function ($fonts) { $fonts['Barlow']='system';$fonts['Barlow Condensed']='system';return $fonts; });
function estiva_widget($type,$settings,$key) { if ($type==='theme-post-title' && class_exists('\Elementor\Plugin')) { $settings['__dynamic__']['title']=\Elementor\Plugin::$instance->dynamic_tags->tag_data_to_tag_text(substr(md5($key),0,7),'post-title'); } return ['id'=>substr(md5('estiva-v3:'.$key),0,7),'elType'=>'widget','widgetType'=>$type,'settings'=>$settings,'elements'=>[]]; }
function estiva_section($widgets,$key,$classes='') { return ['id'=>substr(md5('estiva-v3:section:'.$key),0,7),'elType'=>'section','settings'=>['content_width'=>'full','css_classes'=>$classes],'elements'=>[['id'=>substr(md5('estiva-v3:column:'.$key),0,7),'elType'=>'column','settings'=>['_column_size'=>100],'elements'=>$widgets]]]; }
function estiva_elementor_seed() {
 if (!class_exists('\Elementor\Plugin')) { return new WP_Error('missing_elementor','Ative o Elementor antes de preparar as páginas.'); }
 $count=0;foreach (estiva_pages() as $slug=>$native) {
  $p=get_page_by_path($slug);if (!$p || in_array($slug,['politica-de-privacidade','manutencao'],true) || get_post_meta($p->ID,'_elementor_data',true) || trim($p->post_content)!==trim($native[1])) { continue; }
  $data=[];if ($slug!=='inicio') { $data[]=estiva_section([estiva_widget('heading',['title'=>$p->post_title,'header_size'=>'h1','title_color'=>'#f6f3eb','typography_typography'=>'custom','typography_font_family'=>'Barlow Condensed','typography_font_weight'=>'700'],'title:'.$slug)],'title:'.$slug,'container builder-page-title'); }
  $codes=$slug==='inicio'?['hero','about','beers','deck_intro','units','events','contact']:[];
  if ($codes) { foreach ($codes as $part) { $classes=$part==='hero'?'':('estiva-builder-section home-'.$part);$data[]=estiva_section([estiva_widget('shortcode',['shortcode'=>'[estiva_'.$part.']'],'home:'.$part)],'home:'.$part,$classes); } }
  else { $data[]=estiva_section([estiva_widget('shortcode',['shortcode'=>$native[1]],$slug)],$slug,'estiva-builder-section'); }
  update_post_meta($p->ID,'_elementor_data',wp_slash(wp_json_encode($data)));update_post_meta($p->ID,'_elementor_edit_mode','builder');update_post_meta($p->ID,'_elementor_template_type','wp-page');update_post_meta($p->ID,'_elementor_version',ELEMENTOR_VERSION);update_post_meta($p->ID,'_wp_page_template','page-templates/full-width.php');$count++;
 }
 \Elementor\Plugin::$instance->files_manager->clear_cache();return $count;
}
// Elementor writes shortcode widgets back to post_content. Preserve their order
// and edited settings while restoring native section spacing if it is disabled.
add_filter('the_content',function ($content) {
 if (is_front_page() && !estiva_builder()) { foreach (['about','beers','deck_intro','units','events','contact'] as $part) { $content=str_replace('[estiva_'.$part.']','<section class="home-section home-'.$part.'"><div class="container section">[estiva_'.$part.']</div></section>',$content); } }
 return $content;
},9);
add_action('admin_menu',function () { add_theme_page('Elementor Estiva','Preparar Elementor','manage_options','estiva-elementor',function () {
 if (!current_user_can('manage_options')) { return; }echo '<div class="wrap"><h1>Preparar Elementor</h1><p>Cria layouts nas páginas originais, preservando conteúdo já personalizado e dados Elementor existentes. Os blocos dinâmicos mantêm a edição dos produtos no painel e a operação sem o plugin.</p>';
 if (isset($_POST['estiva_elementor'])) { check_admin_referer('estiva_elementor');$n=estiva_elementor_seed();echo '<p>'.esc_html(is_wp_error($n)?$n->get_error_message():$n.' páginas preparadas.').'</p>'; }echo '<form method="post">';wp_nonce_field('estiva_elementor');echo '<button class="button button-primary" name="estiva_elementor" value="1">Preparar páginas</button></form></div>';
 }); });
if (defined('WP_CLI') && WP_CLI) { WP_CLI::add_command('estiva elementor',function () { $n=estiva_elementor_seed();if (is_wp_error($n)) { WP_CLI::error($n->get_error_message()); }WP_CLI::success($n.' páginas preparadas.'); }); }
