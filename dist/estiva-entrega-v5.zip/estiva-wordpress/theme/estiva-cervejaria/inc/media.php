<?php
if (!defined('ABSPATH')) { exit; }
function estiva_media_catalog() {
 static $catalog=null;if ($catalog===null) { $catalog=json_decode(file_get_contents(get_template_directory().'/assets/media/catalog.json'),true) ?: []; }
 return $catalog;
}
function estiva_media_entry($key) { foreach (estiva_media_catalog() as $entry) { if ($entry['key']===$key) { return $entry; } }return null; }
function estiva_media_attachment($key) {
 $ids=get_posts(['post_type'=>'attachment','post_status'=>'inherit','meta_key'=>'_estiva_media_key','meta_value'=>$key,'numberposts'=>1,'fields'=>'ids']);return $ids?(int)$ids[0]:0;
}
function estiva_media_url($file) { return get_template_directory_uri().'/assets/media/'.rawurlencode(basename($file)); }
function estiva_media_image($key,$attrs=[]) {
 $entry=estiva_media_entry($key);if (!$entry) { return ''; }
 $custom_alt=array_key_exists('alt',$attrs);$attrs=wp_parse_args($attrs,['alt'=>$entry['alt'],'loading'=>'lazy','decoding'=>'async','sizes'=>'(max-width:767px)100vw,50vw']);
 $attachment=estiva_media_attachment($key);if ($attachment && wp_attachment_is_image($attachment)) { if (!$custom_alt) { unset($attrs['alt']); }return wp_get_attachment_image($attachment,'large',false,$attrs); }
 $variants=$entry['variants'];$main=end($variants);$attributes=['src'=>estiva_media_url($main['file']),'width'=>$main['width'],'height'=>$main['height'],'srcset'=>implode(', ',array_map(static function ($v) { return estiva_media_url($v['file']).' '.$v['width'].'w'; },$variants))]+$attrs;
 $html='<img';foreach ($attributes as $name=>$value) { if (in_array($name,['src','srcset','width','height','alt','class','loading','decoding','sizes','fetchpriority'],true)) { $html.=' '.esc_attr($name).'="'.esc_attr($value).'"'; } }return $html.'>';
}
function estiva_gallery_ids($value) {
 if (!is_scalar($value)) { return ''; }$ids=array_unique(array_filter(array_map('absint',explode(',',(string)$value))));return implode(',',array_slice($ids,0,30));
}
function estiva_gallery_groups() { return ['brewpub'=>'Brewpub na Avenida Ana Costa','fabrica'=>'Fábrica junto ao Brewpub','quiosque'=>'Quiosque na praia do Canal 3','eventos'=>'Registros de eventos','historia'=>'Memória do Praiamar — unidade encerrada']; }
function estiva_media_video($entry) {
 $attachment=estiva_media_attachment($entry['key'].':video');$url=$attachment?wp_get_attachment_url($attachment):estiva_media_url($entry['video']);$poster=$entry['variants'][1];
 return '<video class="estiva-ambient-video" controls muted playsinline preload="none" poster="'.esc_url(estiva_media_url($poster['file'])).'" width="'.(int)$poster['width'].'" height="'.(int)$poster['height'].'" aria-label="'.esc_attr($entry['alt']).'"><source src="'.esc_url($url).'" type="video/mp4"><a href="'.esc_url($url).'">Abrir vídeo do quiosque</a></video>';
}
function estiva_gallery_markup($group) {
 if (!isset(estiva_gallery_groups()[$group])) { return ''; }
 $custom=estiva_gallery_ids(get_theme_mod('estiva_gallery_'.$group,''));$items='';
 if ($custom) {
  foreach (explode(',',$custom) as $id) { if (!wp_attachment_is_image($id)) { continue; }$caption=wp_get_attachment_caption($id) ?: get_post_meta($id,'_wp_attachment_image_alt',true);if ($group==='historia') { $caption.=' — Antiga loja Praiamar, unidade encerrada.'; }$items.='<figure>'.wp_get_attachment_image($id,'large',false,['loading'=>'lazy','sizes'=>'(max-width:767px)100vw,33vw']).'<figcaption>'.esc_html($caption).'</figcaption></figure>'; }
 } else {
  foreach (estiva_media_catalog() as $entry) { if ($entry['group']!==$group) { continue; }$media=isset($entry['video'])?estiva_media_video($entry):estiva_media_image($entry['key'],['sizes'=>'(max-width:767px)100vw,33vw']);$items.='<figure data-estiva-media="'.esc_attr($entry['key']).'">'.$media.'<figcaption>'.esc_html($entry['alt']).'</figcaption></figure>'; }
 }
 return '<div class="estiva-gallery" data-gallery="'.esc_attr($group).'">'.$items.'</div>';
}
add_shortcode('estiva_gallery',function ($atts) { $atts=shortcode_atts(['group'=>'brewpub'],$atts);return estiva_gallery_markup($atts['group']); });
add_shortcode('estiva_history',function () {
 return '<section class="estiva-memory" aria-labelledby="estiva-memory-title"><span class="eyebrow">Parte da nossa história</span><h2 id="estiva-memory-title">Praiamar: encontros que ficaram na memória.</h2><p>A trajetória da Estiva também passou pelo Shopping Praiamar. Essa unidade foi encerrada no início de 2026. As fotos abaixo fazem parte do nosso acervo e não representam uma unidade em funcionamento.</p><p class="note">Valores, ofertas e informações visíveis nas fotos são registros históricos.</p>'.estiva_gallery_markup('historia').'</section>';
});
function estiva_import_media() {
 if (!current_user_can('upload_files') || !current_user_can('manage_options')) { return new WP_Error('forbidden','Permissão insuficiente.'); }
 require_once ABSPATH.'wp-admin/includes/image.php';$created=0;
 foreach (estiva_media_catalog() as $entry) {
  $variants=$entry['variants'];$main=end($variants);$files=[['key'=>$entry['key'],'file'=>$main['file'],'mime'=>'image/webp']];
  if (isset($entry['video'])) { $files[]=['key'=>$entry['key'].':video','file'=>$entry['video'],'mime'=>'video/mp4']; }
  foreach ($files as $file) {
   if (estiva_media_attachment($file['key'])) { continue; }
   $path=get_template_directory().'/assets/media/'.basename($file['file']);$upload=wp_upload_bits(basename($file['file']),null,file_get_contents($path));
   if ($upload['error']) { return new WP_Error('upload',$upload['error']); }
   $id=wp_insert_attachment(['post_mime_type'=>$file['mime'],'post_title'=>$entry['alt'],'post_excerpt'=>$entry['alt'],'post_status'=>'inherit'],$upload['file'],0,true);
   if (is_wp_error($id)) { return $id; }
   update_post_meta($id,'_estiva_media_key',$file['key']);if ($file['mime']==='image/webp') { update_post_meta($id,'_wp_attachment_image_alt',$entry['alt']);wp_update_attachment_metadata($id,wp_generate_attachment_metadata($id,$upload['file'])); }$created++;
  }
 }
 return $created;
}
add_action('customize_register',function ($c) {
 $c->add_section('estiva_galleries',['title'=>'Estiva — galerias de fotos','priority'=>31]);
 foreach (estiva_gallery_groups() as $group=>$label) { $id='estiva_gallery_'.$group;$c->add_setting($id,['default'=>'','sanitize_callback'=>'estiva_gallery_ids']);$c->add_control($id,['label'=>$label,'description'=>'IDs das imagens da biblioteca separados por vírgula, na ordem desejada. Vazio usa o acervo incluído.','section'=>'estiva_galleries','type'=>'textarea']); }
});
add_action('admin_menu',function () { add_theme_page('Acervo Estiva','Acervo Estiva','manage_options','estiva-media',function () {
 if (!current_user_can('manage_options')) { return; }
 echo '<div class="wrap"><h1>Acervo Estiva</h1><p>As fotos e o vídeo já aparecem no site a partir dos arquivos do tema. Para selecioná-los nos widgets do Elementor e na biblioteca de mídia, importe uma cópia otimizada. O importador não duplica o acervo nem substitui arquivos existentes.</p><p>Praiamar é memória de uma unidade encerrada no início de 2026, nunca uma unidade ativa.</p>';
 if (isset($_POST['estiva_media_import'])) { check_admin_referer('estiva_media_import');$result=estiva_import_media();echo '<p role="status">'.esc_html(is_wp_error($result)?$result->get_error_message():$result.' mídias importadas.').'</p>'; }
 echo '<form method="post">';wp_nonce_field('estiva_media_import');echo '<button class="button button-primary" name="estiva_media_import" value="1">Importar acervo para a biblioteca</button></form></div>';
 }); });
if (defined('WP_CLI') && WP_CLI) { WP_CLI::add_command('estiva media',function () { $result=estiva_import_media();if (is_wp_error($result)) { WP_CLI::error($result->get_error_message()); }WP_CLI::success($result.' mídias importadas.'); }); }
