# Estiva v3

Use skills/estiva-wordpress/SKILL.md. O pedido de 28/10/2026 substitui o escopo
anterior PUB/Club: nova versão institucional, cardápio Deck editável e integração
com Elementor Pro, que o usuário informou estar em uma instalação local de testes.
Não copie a licença, não inclua o plugin Pro nos ZIPs do tema e não alegue testar
Pro sem acesso ao plugin real. Nunca invente contatos, métricas ou preços.

A versão anterior está preservada em previous/v2 e em backup fora do checkout.
Não a apague. Este checkout já é isolado; não crie worktrees sem pedido explícito.
Credenciais de QA ficam fora do repositório. Rode fixtures só em QA descartável.
Registre evidências da execução atual; não reutilize resultados antigos como novos.

## Revisão v4 — páginas e migração

O usuário pediu páginas Início, Unidades (PUB Ana Costa e quiosque Canal 3), Sobre e Contato. As oito páginas ausentes são criadas no primeiro acesso administrativo, preservando páginas existentes. Formulário destinado a faleconosco@estivacervejaria.com.br, confirmado pelo usuário. Fotos reais das duas unidades e histórico detalhado continuam pendentes; o site público segue bloqueado por HTTP 403. Não alegue migrar esses conteúdos sem os materiais. Testes de e-mail usam interceptor local, nunca disparam mensagem externa sem autorização. Evidências atuais em docs/evidence-v4; docs/evidence é histórico v3. Versão v3 preservada em previous/v3 e branch entrega-estiva-v3.

## Revisão v5 — 11/11/2026

O usuário forneceu fotos/vídeos reais e confirmou Brewpub/Fábrica juntos na Ana Costa; Praiamar fechado no início de 2026, apenas histórico. Foram processadas 22 HEIC e um MOV curto; dois MP4 excedem o limite de 32 MiB e continuam pendentes. Não invente conversão desses vídeos nem reabra o Praiamar na listagem ativa. Os originais estão fora do checkout em /workspace/estiva-v5-media e attachments; derivados publicados em assets/media. Há importador opt-in para biblioteca, idempotente.
O usuário pediu manutenção para trabalhar em produção: controle Aparência → Manutenção Estiva, padrão desligado, visitantes recebem503, editores/admins autenticados podem trabalhar, REST público bloqueado. Sempre restaure a opção após fixtures em QA, jamais ative em produção sem instrução. Nenhum servidor público foi alterado. Evidências atuais evidence-v5; pacote exclui evidências anteriores mas as preserva no workspace.
